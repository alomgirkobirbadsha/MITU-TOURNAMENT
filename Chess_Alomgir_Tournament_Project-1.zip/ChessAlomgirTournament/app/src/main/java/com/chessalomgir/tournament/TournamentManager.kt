package com.chessalomgir.tournament

data class TournamentFixture(
    val matchNumber: Int,
    val whitePlayer: String,
    val blackPlayer: String
)

object TournamentManager {
    val defaultPlayers = listOf("Alomgir", "Tariq", "Nabil", "Rafi")

    fun buildRoundRobinFixtures(players: List<String> = defaultPlayers): List<TournamentFixture> {
        val list = if (players.size >= 4) players.take(4) else defaultPlayers
        val pairs = listOf(
            list[0] to list[1],
            list[2] to list[3],
            list[0] to list[2],
            list[1] to list[3],
            list[0] to list[3],
            list[1] to list[2]
        )
        return pairs.mapIndexed { index, (w, b) ->
            TournamentFixture(
                matchNumber = index + 1,
                whitePlayer = w,
                blackPlayer = b
            )
        }
    }
}
