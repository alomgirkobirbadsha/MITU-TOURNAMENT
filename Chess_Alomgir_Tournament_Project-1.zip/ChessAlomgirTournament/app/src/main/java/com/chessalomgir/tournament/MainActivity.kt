package com.chessalomgir.tournament

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.delay

private val NavyDark = Color(0xFF0A1628)
private val NavyCard = Color(0xFF13243E)
private val BoardDark = Color(0xFF1B365D)
private val BoardLight = Color(0xFFF3E5AB)
private val GoldAccent = Color(0xFFD4AF37)
private val SelectedGold = Color(0xFFE6C85C)
private const val MOVE_SECONDS = 30

private data class PlayerStanding(
    val name: String,
    val wins: Int = 0,
    val draws: Int = 0,
    val points: Double = 0.0
)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            ChessAlomgirTournamentApp()
        }
    }
}

@Composable
fun ChessAlomgirTournamentApp() {
    val players = remember {
        mutableStateListOf<String>().apply {
            addAll(TournamentManager.defaultPlayers)
        }
    }
    var showEditPlayers by remember { mutableStateOf(false) }
    var showStandings by remember { mutableStateOf(false) }
    var resetCounter by remember { mutableIntStateOf(0) }

    val fixtures = remember(players.toList()) {
        TournamentManager.buildRoundRobinFixtures(players.toList())
    }
    var fixtureIndex by remember(resetCounter) { mutableIntStateOf(0) }
    val currentFixture = fixtures[fixtureIndex % fixtures.size]

    var match by remember(fixtureIndex, resetCounter) { mutableStateOf(ChessEngine.newMatch()) }
    var selected by remember(fixtureIndex, resetCounter) { mutableStateOf<Square?>(null) }
    var pendingPromo by remember(fixtureIndex, resetCounter) { mutableStateOf<Pair<Square, Square>?>(null) }
    var secondsLeft by remember(fixtureIndex, resetCounter, match.turn, match.outcome) {
        mutableIntStateOf(MOVE_SECONDS)
    }
    var matchScored by remember(fixtureIndex, resetCounter) { mutableStateOf(false) }

    var standingsMap by remember(players.toList(), resetCounter) {
        mutableStateOf(players.associateWith { name -> PlayerStanding(name = name) })
    }

    fun resetTournamentStandings() {
        standingsMap = players.associateWith { name -> PlayerStanding(name = name) }
        fixtureIndex = 0
        matchScored = false
        selected = null
        pendingPromo = null
        match = ChessEngine.newMatch()
        resetCounter++
    }

    fun awardResult(winnerSide: Side?, isDraw: Boolean) {
        if (matchScored) return
        matchScored = true
        val updated = standingsMap.toMutableMap()
        val whiteName = currentFixture.whitePlayer
        val blackName = currentFixture.blackPlayer
        val wStat = updated[whiteName] ?: PlayerStanding(whiteName)
        val bStat = updated[blackName] ?: PlayerStanding(blackName)

        if (isDraw) {
            updated[whiteName] = wStat.copy(draws = wStat.draws + 1, points = wStat.points + 0.5)
            updated[blackName] = bStat.copy(draws = bStat.draws + 1, points = bStat.points + 0.5)
        } else if (winnerSide == Side.WHITE) {
            updated[whiteName] = wStat.copy(wins = wStat.wins + 1, points = wStat.points + 1.0)
        } else if (winnerSide == Side.BLACK) {
            updated[blackName] = bStat.copy(wins = bStat.wins + 1, points = bStat.points + 1.0)
        }
        standingsMap = updated
    }

    LaunchedEffect(fixtureIndex, resetCounter, match.turn, match.outcome) {
        secondsLeft = MOVE_SECONDS
        if (match.outcome != GameOutcome.IN_PROGRESS) return@LaunchedEffect
        while (secondsLeft > 0) {
            delay(1000L)
            secondsLeft--
        }
        val winnerSide = if (match.turn == Side.WHITE) Side.BLACK else Side.WHITE
        val winnerName = if (winnerSide == Side.WHITE) currentFixture.whitePlayer else currentFixture.blackPlayer
        match = match.copy(
            outcome = GameOutcome.CHECKMATE,
            winner = winnerSide,
            statusText = "Time out! $winnerName wins"
        )
        awardResult(winnerSide = winnerSide, isDraw = false)
    }

    val legalMoves = remember(match) { ChessEngine.legalMoves(match, match.turn) }

    fun commitMove(move: Move) {
        val next = ChessEngine.playMove(match, move)
        if (next != match) {
            match = next
            selected = null
            when (next.outcome) {
                GameOutcome.CHECKMATE -> awardResult(winnerSide = next.winner, isDraw = false)
                GameOutcome.STALEMATE -> awardResult(winnerSide = null, isDraw = true)
                GameOutcome.IN_PROGRESS -> Unit
            }
        }
    }

    if (showStandings) {
        val ranked = standingsMap.values
            .sortedWith(compareByDescending<PlayerStanding> { it.points }.thenByDescending { it.wins })
        AlertDialog(
            onDismissRequest = { showStandings = false },
            containerColor = NavyCard,
            titleContentColor = GoldAccent,
            title = { Text("Tournament Standings", fontWeight = FontWeight.Bold) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Row(modifier = Modifier.fillMaxWidth()) {
                        Text("#", color = GoldAccent, fontWeight = FontWeight.Bold, modifier = Modifier.weight(0.6f))
                        Text("Player", color = GoldAccent, fontWeight = FontWeight.Bold, modifier = Modifier.weight(2f))
                        Text("W", color = GoldAccent, fontWeight = FontWeight.Bold, modifier = Modifier.weight(0.7f))
                        Text("D", color = GoldAccent, fontWeight = FontWeight.Bold, modifier = Modifier.weight(0.7f))
                        Text("Pts", color = GoldAccent, fontWeight = FontWeight.Bold, modifier = Modifier.weight(0.9f))
                    }
                    ranked.forEachIndexed { idx, s ->
                        Row(modifier = Modifier.fillMaxWidth()) {
                            Text("${idx + 1}", color = GoldAccent, modifier = Modifier.weight(0.6f))
                            Text(s.name, color = Color.White, fontWeight = FontWeight.SemiBold, modifier = Modifier.weight(2f))
                            Text("${s.wins}", color = Color.White, modifier = Modifier.weight(0.7f))
                            Text("${s.draws}", color = Color.White, modifier = Modifier.weight(0.7f))
                            Text("${s.points}", color = GoldAccent, fontWeight = FontWeight.Bold, modifier = Modifier.weight(0.9f))
                        }
                    }
                }
            },
            confirmButton = {
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    TextButton(
                        onClick = {
                            resetTournamentStandings()
                            showStandings = false
                        }
                    ) {
                        Text("Reset Standings", color = Color(0xFFFF6B6B), fontWeight = FontWeight.Bold)
                    }
                    Button(
                        onClick = { showStandings = false },
                        colors = ButtonDefaults.buttonColors(
                            containerColor = GoldAccent,
                            contentColor = NavyDark
                        )
                    ) {
                        Text("Close", fontWeight = FontWeight.Bold)
                    }
                }
            }
        )
    }

    if (showEditPlayers) {
        val draftNames = remember(players.toList()) {
            mutableStateListOf<String>().apply { addAll(players) }
        }
        AlertDialog(
            onDismissRequest = { showEditPlayers = false },
            containerColor = NavyCard,
            titleContentColor = GoldAccent,
            title = { Text("Edit 4 Players", fontWeight = FontWeight.Bold) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    for (idx in 0..3) {
                        OutlinedTextField(
                            value = draftNames[idx],
                            onValueChange = { draftNames[idx] = it },
                            singleLine = true,
                            label = { Text("Player ${idx + 1}", color = GoldAccent) },
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedTextColor = Color.White,
                                unfocusedTextColor = Color.White,
                                focusedBorderColor = GoldAccent,
                                unfocusedBorderColor = BoardLight.copy(alpha = 0.5f)
                            )
                        )
                    }
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        for (idx in 0..3) {
                            val trimmed = draftNames[idx].trim()
                            players[idx] = if (trimmed.isNotEmpty()) trimmed else "Player ${idx + 1}"
                        }
                        resetTournamentStandings()
                        showEditPlayers = false
                    },
                    colors = ButtonDefaults.buttonColors(
                        containerColor = GoldAccent,
                        contentColor = NavyDark
                    )
                ) {
                    Text("Save & Reset", fontWeight = FontWeight.Bold)
                }
            },
            dismissButton = {
                TextButton(onClick = { showEditPlayers = false }) {
                    Text("Cancel", color = GoldAccent)
                }
            }
        )
    }

    if (pendingPromo != null) {
        val (fromSq, toSq) = pendingPromo!!
        AlertDialog(
            onDismissRequest = { pendingPromo = null },
            containerColor = NavyCard,
            titleContentColor = GoldAccent,
            title = { Text("Promote Pawn", fontWeight = FontWeight.Bold) },
            text = {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    listOf(
                        PieceType.QUEEN to "Q",
                        PieceType.ROOK to "R",
                        PieceType.BISHOP to "B",
                        PieceType.KNIGHT to "N"
                    ).forEach { (type, label) ->
                        Button(
                            onClick = {
                                pendingPromo = null
                                commitMove(Move(fromSq, toSq, type))
                            },
                            colors = ButtonDefaults.buttonColors(
                                containerColor = GoldAccent,
                                contentColor = NavyDark
                            ),
                            modifier = Modifier.weight(1f)
                        ) {
                            Text(label, fontWeight = FontWeight.Bold)
                        }
                    }
                }
            },
            confirmButton = {}
        )
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(NavyDark)
            .padding(14.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text(
            text = "CHESS ALOMGIR TOURNAMENT",
            color = GoldAccent,
            fontSize = 19.sp,
            fontWeight = FontWeight.Bold
        )
        Spacer(modifier = Modifier.height(8.dp))

        Card(
            colors = CardDefaults.cardColors(containerColor = NavyCard),
            modifier = Modifier
                .fillMaxWidth()
                .border(1.dp, GoldAccent, RoundedCornerShape(10.dp)),
            shape = RoundedCornerShape(10.dp)
        ) {
            Column(modifier = Modifier.padding(10.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text(
                        text = "B${currentFixture.matchNumber}/${fixtures.size}: ${currentFixture.whitePlayer} vs ${currentFixture.blackPlayer}",
                        color = GoldAccent,
                        fontSize = 13.sp,
                        fontWeight = FontWeight.Bold
                    )
                    Text(
                        text = "${secondsLeft}s",
                        color = if (secondsLeft <= 5) Color(0xFFFF6B6B) else Color.White,
                        fontSize = 14.sp,
                        fontWeight = FontWeight.Bold
                    )
                }
                Spacer(modifier = Modifier.height(4.dp))
                Text(
                    text = match.statusText,
                    color = Color.White,
                    fontSize = 14.sp,
                    fontWeight = FontWeight.SemiBold
                )
                Spacer(modifier = Modifier.height(4.dp))
                Text(
                    text = players.joinToString("  •  ") { p -> "$p: ${standingsMap[p]?.points ?: 0.0}" },
                    color = GoldAccent,
                    fontSize = 11.sp
                )
            }
        }

        Spacer(modifier = Modifier.height(10.dp))

        Column(
            modifier = Modifier
                .fillMaxWidth()
                .border(2.dp, GoldAccent)
        ) {
            for (r in 0..7) {
                Row(modifier = Modifier.fillMaxWidth()) {
                    for (c in 0..7) {
                        val sq = Square(r, c)
                        val isLight = (r + c) % 2 == 0
                        val piece = match.grid[r][c]
                        val isSelected = selected == sq
                        val isTarget = selected != null && legalMoves.any { it.from == selected && it.to == sq }

                        val cellColor = when {
                            isSelected -> SelectedGold
                            isLight -> BoardLight
                            else -> BoardDark
                        }

                        Box(
                            modifier = Modifier
                                .weight(1f)
                                .aspectRatio(1f)
                                .background(cellColor)
                                .border(
                                    width = if (isTarget) 2.dp else 0.dp,
                                    color = if (isTarget) GoldAccent else Color.Transparent
                                )
                                .clickable(enabled = match.outcome == GameOutcome.IN_PROGRESS) {
                                    val cur = selected
                                    if (cur == null) {
                                        if (piece?.side == match.turn) {
                                            selected = sq
                                        }
                                    } else if (cur == sq) {
                                        selected = null
                                    } else if (legalMoves.any { it.from == cur && it.to == sq }) {
                                        if (ChessEngine.isPromotion(match, cur, sq)) {
                                            pendingPromo = cur to sq
                                        } else {
                                            commitMove(Move(cur, sq))
                                        }
                                    } else if (piece?.side == match.turn) {
                                        selected = sq
                                    } else {
                                        selected = null
                                    }
                                },
                            contentAlignment = Alignment.Center
                        ) {
                            if (piece != null) {
                                Text(
                                    text = pieceSymbol(piece),
                                    fontSize = 26.sp,
                                    color = if (piece.side == Side.WHITE) Color.White else NavyDark
                                )
                            }
                        }
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(10.dp))

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            Button(
                onClick = { showEditPlayers = true },
                colors = ButtonDefaults.buttonColors(
                    containerColor = NavyCard,
                    contentColor = GoldAccent
                ),
                modifier = Modifier
                    .weight(0.95f)
                    .border(1.dp, GoldAccent, RoundedCornerShape(20.dp))
            ) {
                Text("PLAYERS", fontWeight = FontWeight.Bold, fontSize = 10.sp)
            }

            Button(
                onClick = { showStandings = true },
                colors = ButtonDefaults.buttonColors(
                    containerColor = NavyCard,
                    contentColor = GoldAccent
                ),
                modifier = Modifier
                    .weight(1.05f)
                    .border(1.dp, GoldAccent, RoundedCornerShape(20.dp))
            ) {
                Text("STANDINGS", fontWeight = FontWeight.Bold, fontSize = 10.sp)
            }

            Button(
                onClick = { resetTournamentStandings() },
                colors = ButtonDefaults.buttonColors(
                    containerColor = NavyCard,
                    contentColor = GoldAccent
                ),
                modifier = Modifier
                    .weight(0.95f)
                    .border(1.dp, GoldAccent, RoundedCornerShape(20.dp))
            ) {
                Text("RESET PTS", fontWeight = FontWeight.Bold, fontSize = 10.sp)
            }

            Button(
                onClick = {
                    fixtureIndex = (fixtureIndex + 1) % fixtures.size
                },
                colors = ButtonDefaults.buttonColors(
                    containerColor = GoldAccent,
                    contentColor = NavyDark
                ),
                modifier = Modifier.weight(1.1f)
            ) {
                Text("NEXT MATCH", fontWeight = FontWeight.Bold, fontSize = 10.sp)
            }
        }
    }
}

private fun pieceSymbol(piece: Piece): String = when (piece.side) {
    Side.WHITE -> when (piece.type) {
        PieceType.KING -> "♔"
        PieceType.QUEEN -> "♕"
        PieceType.ROOK -> "♖"
        PieceType.BISHOP -> "♗"
        PieceType.KNIGHT -> "♘"
        PieceType.PAWN -> "♙"
    }
    Side.BLACK -> when (piece.type) {
        PieceType.KING -> "♚"
        PieceType.QUEEN -> "♛"
        PieceType.ROOK -> "♜"
        PieceType.BISHOP -> "♝"
        PieceType.KNIGHT -> "♞"
        PieceType.PAWN -> "♟"
    }
}
