package com.chessalomgir.tournament

import kotlin.math.abs

enum class PieceType { PAWN, ROOK, KNIGHT, BISHOP, QUEEN, KING }
enum class Side { WHITE, BLACK }

data class Piece(
    val type: PieceType,
    val side: Side,
    val hasMoved: Boolean = false
)

data class Square(val row: Int, val col: Int)

data class Move(
    val from: Square,
    val to: Square,
    val promotion: PieceType = PieceType.QUEEN
)

enum class GameOutcome {
    IN_PROGRESS,
    CHECKMATE,
    STALEMATE
}

data class MatchState(
    val grid: Array<Array<Piece?>>,
    val turn: Side = Side.WHITE,
    val enPassant: Square? = null,
    val statusText: String = "White to move",
    val outcome: GameOutcome = GameOutcome.IN_PROGRESS,
    val winner: Side? = null
) {
    override fun equals(other: Any?): Boolean {
        if (this === other) return true
        if (other !is MatchState) return false
        return turn == other.turn &&
            enPassant == other.enPassant &&
            statusText == other.statusText &&
            outcome == other.outcome &&
            winner == other.winner &&
            grid.contentDeepEquals(other.grid)
    }

    override fun hashCode(): Int {
        var result = grid.contentDeepHashCode()
        result = 31 * result + turn.hashCode()
        result = 31 * result + (enPassant?.hashCode() ?: 0)
        result = 31 * result + statusText.hashCode()
        return result
    }
}

object ChessEngine {
    fun newMatch(): MatchState {
        val grid = Array(8) { arrayOfNulls<Piece>(8) }
        val backRank = listOf(
            PieceType.ROOK, PieceType.KNIGHT, PieceType.BISHOP, PieceType.QUEEN,
            PieceType.KING, PieceType.BISHOP, PieceType.KNIGHT, PieceType.ROOK
        )
        for (col in 0..7) {
            grid[0][col] = Piece(backRank[col], Side.BLACK)
            grid[1][col] = Piece(PieceType.PAWN, Side.BLACK)
            grid[6][col] = Piece(PieceType.PAWN, Side.WHITE)
            grid[7][col] = Piece(backRank[col], Side.WHITE)
        }
        return MatchState(grid = grid, turn = Side.WHITE, statusText = "White to move")
    }

    fun legalMoves(state: MatchState, side: Side = state.turn): List<Move> {
        if (state.outcome != GameOutcome.IN_PROGRESS) return emptyList()
        val result = mutableListOf<Move>()
        val enemy = if (side == Side.WHITE) Side.BLACK else Side.WHITE

        for (r in 0..7) {
            for (c in 0..7) {
                val p = state.grid[r][c] ?: continue
                if (p.side != side) continue
                val from = Square(r, c)
                val pseudo = mutableListOf<Move>()

                when (p.type) {
                    PieceType.PAWN -> {
                        val dir = if (side == Side.WHITE) -1 else 1
                        val startRow = if (side == Side.WHITE) 6 else 1
                        val r1 = r + dir
                        if (r1 in 0..7 && state.grid[r1][c] == null) {
                            pseudo.add(Move(from, Square(r1, c)))
                            val r2 = r + 2 * dir
                            if (r == startRow && state.grid[r2][c] == null) {
                                pseudo.add(Move(from, Square(r2, c)))
                            }
                        }
                        for (dc in listOf(-1, 1)) {
                            val nc = c + dc
                            if (r1 in 0..7 && nc in 0..7) {
                                val target = state.grid[r1][nc]
                                if (target != null && target.side == enemy) {
                                    pseudo.add(Move(from, Square(r1, nc)))
                                } else if (state.enPassant == Square(r1, nc)) {
                                    pseudo.add(Move(from, Square(r1, nc)))
                                }
                            }
                        }
                    }

                    PieceType.KNIGHT -> {
                        for ((dr, dc) in listOf(
                            -2 to -1, -2 to 1, -1 to -2, -1 to 2,
                            1 to -2, 1 to 2, 2 to -1, 2 to 1
                        )) {
                            val nr = r + dr
                            val nc = c + dc
                            if (nr in 0..7 && nc in 0..7) {
                                val t = state.grid[nr][nc]
                                if (t == null || t.side == enemy) pseudo.add(Move(from, Square(nr, nc)))
                            }
                        }
                    }

                    PieceType.BISHOP -> addRays(state.grid, from, side, enemy, listOf(-1 to -1, -1 to 1, 1 to -1, 1 to 1), pseudo)
                    PieceType.ROOK -> addRays(state.grid, from, side, enemy, listOf(-1 to 0, 1 to 0, 0 to -1, 0 to 1), pseudo)
                    PieceType.QUEEN -> addRays(
                        state.grid, from, side, enemy,
                        listOf(-1 to -1, -1 to 1, 1 to -1, 1 to 1, -1 to 0, 1 to 0, 0 to -1, 0 to 1),
                        pseudo
                    )

                    PieceType.KING -> {
                        for (dr in -1..1) {
                            for (dc in -1..1) {
                                if (dr == 0 && dc == 0) continue
                                val nr = r + dr
                                val nc = c + dc
                                if (nr in 0..7 && nc in 0..7) {
                                    val t = state.grid[nr][nc]
                                    if (t == null || t.side == enemy) pseudo.add(Move(from, Square(nr, nc)))
                                }
                            }
                        }
                        if (!p.hasMoved && c == 4 && !isSquareAttacked(state.grid, from, enemy)) {
                            val kr = state.grid[r][7]
                            if (kr?.type == PieceType.ROOK && kr.side == side && !kr.hasMoved &&
                                state.grid[r][5] == null && state.grid[r][6] == null &&
                                !isSquareAttacked(state.grid, Square(r, 5), enemy) &&
                                !isSquareAttacked(state.grid, Square(r, 6), enemy)
                            ) {
                                pseudo.add(Move(from, Square(r, 6)))
                            }
                            val qr = state.grid[r][0]
                            if (qr?.type == PieceType.ROOK && qr.side == side && !qr.hasMoved &&
                                state.grid[r][1] == null && state.grid[r][2] == null && state.grid[r][3] == null &&
                                !isSquareAttacked(state.grid, Square(r, 3), enemy) &&
                                !isSquareAttacked(state.grid, Square(r, 2), enemy)
                            ) {
                                pseudo.add(Move(from, Square(r, 2)))
                            }
                        }
                    }
                }

                for (m in pseudo) {
                    val nextGrid = applyMove(state.grid, m, state.enPassant)
                    if (!isInCheck(nextGrid, side)) {
                        result.add(m)
                    }
                }
            }
        }
        return result
    }

    fun playMove(state: MatchState, move: Move): MatchState {
        val legal = legalMoves(state, state.turn)
        val chosen = legal.firstOrNull { it.from == move.from && it.to == move.to } ?: return state
        val finalMove = chosen.copy(promotion = move.promotion)

        val piece = state.grid[finalMove.from.row][finalMove.from.col] ?: return state
        val nextGrid = applyMove(state.grid, finalMove, state.enPassant)
        val nextEp = if (piece.type == PieceType.PAWN && abs(finalMove.to.row - finalMove.from.row) == 2) {
            Square((finalMove.from.row + finalMove.to.row) / 2, finalMove.from.col)
        } else {
            null
        }
        val nextTurn = if (state.turn == Side.WHITE) Side.BLACK else Side.WHITE
        val nextBase = MatchState(grid = nextGrid, turn = nextTurn, enPassant = nextEp)
        val nextMoves = legalMoves(nextBase, nextTurn)

        return when {
            nextMoves.isEmpty() && isInCheck(nextGrid, nextTurn) -> MatchState(
                grid = nextGrid,
                turn = nextTurn,
                enPassant = null,
                statusText = "Checkmate! ${state.turn.name} wins",
                outcome = GameOutcome.CHECKMATE,
                winner = state.turn
            )
            nextMoves.isEmpty() -> MatchState(
                grid = nextGrid,
                turn = nextTurn,
                enPassant = null,
                statusText = "Draw by stalemate",
                outcome = GameOutcome.STALEMATE,
                winner = null
            )
            isInCheck(nextGrid, nextTurn) -> MatchState(
                grid = nextGrid,
                turn = nextTurn,
                enPassant = nextEp,
                statusText = "${nextTurn.name.lowercase().replaceFirstChar { it.uppercase() }} in check",
                outcome = GameOutcome.IN_PROGRESS
            )
            else -> MatchState(
                grid = nextGrid,
                turn = nextTurn,
                enPassant = nextEp,
                statusText = "${nextTurn.name.lowercase().replaceFirstChar { it.uppercase() }} to move",
                outcome = GameOutcome.IN_PROGRESS
            )
        }
    }

    fun isPromotion(state: MatchState, from: Square, to: Square): Boolean {
        val p = state.grid[from.row][from.col] ?: return false
        if (p.type != PieceType.PAWN) return false
        return (p.side == Side.WHITE && to.row == 0) || (p.side == Side.BLACK && to.row == 7)
    }

    private fun applyMove(source: Array<Array<Piece?>>, move: Move, ep: Square?): Array<Array<Piece?>> {
        val g = Array(8) { r -> source[r].copyOf() }
        val moving = g[move.from.row][move.from.col] ?: return g
        g[move.from.row][move.from.col] = null

        if (moving.type == PieceType.PAWN && move.to == ep && g[move.to.row][move.to.col] == null) {
            g[move.from.row][move.to.col] = null
        }

        if (moving.type == PieceType.KING && abs(move.to.col - move.from.col) == 2) {
            val row = move.from.row
            if (move.to.col == 6) {
                val rook = g[row][7]
                g[row][7] = null
                g[row][5] = rook?.copy(hasMoved = true)
            } else if (move.to.col == 2) {
                val rook = g[row][0]
                g[row][0] = null
                g[row][3] = rook?.copy(hasMoved = true)
            }
        }

        val promoRank = (moving.side == Side.WHITE && move.to.row == 0) || (moving.side == Side.BLACK && move.to.row == 7)
        g[move.to.row][move.to.col] = if (moving.type == PieceType.PAWN && promoRank) {
            Piece(move.promotion, moving.side, hasMoved = true)
        } else {
            moving.copy(hasMoved = true)
        }
        return g
    }

    fun isInCheck(grid: Array<Array<Piece?>>, side: Side): Boolean {
        var kingSq: Square? = null
        for (r in 0..7) {
            for (c in 0..7) {
                val p = grid[r][c]
                if (p?.side == side && p.type == PieceType.KING) {
                    kingSq = Square(r, c)
                }
            }
        }
        val target = kingSq ?: return true
        val enemy = if (side == Side.WHITE) Side.BLACK else Side.WHITE
        return isSquareAttacked(grid, target, enemy)
    }

    private fun isSquareAttacked(grid: Array<Array<Piece?>>, sq: Square, bySide: Side): Boolean {
        val pDir = if (bySide == Side.WHITE) -1 else 1
        val pRow = sq.row - pDir
        if (pRow in 0..7) {
            for (dc in listOf(-1, 1)) {
                val nc = sq.col + dc
                if (nc in 0..7 && grid[pRow][nc]?.side == bySide && grid[pRow][nc]?.type == PieceType.PAWN) {
                    return true
                }
            }
        }
        for ((dr, dc) in listOf(
            -2 to -1, -2 to 1, -1 to -2, -1 to 2,
            1 to -2, 1 to 2, 2 to -1, 2 to 1
        )) {
            val nr = sq.row + dr
            val nc = sq.col + dc
            if (nr in 0..7 && nc in 0..7 && grid[nr][nc]?.side == bySide && grid[nr][nc]?.type == PieceType.KNIGHT) {
                return true
            }
        }
        for (dr in -1..1) {
            for (dc in -1..1) {
                if (dr == 0 && dc == 0) continue
                val nr = sq.row + dr
                val nc = sq.col + dc
                if (nr in 0..7 && nc in 0..7 && grid[nr][nc]?.side == bySide && grid[nr][nc]?.type == PieceType.KING) {
                    return true
                }
            }
        }
        for ((dr, dc) in listOf(-1 to 0, 1 to 0, 0 to -1, 0 to 1)) {
            var nr = sq.row + dr
            var nc = sq.col + dc
            while (nr in 0..7 && nc in 0..7) {
                val p = grid[nr][nc]
                if (p != null) {
                    if (p.side == bySide && (p.type == PieceType.ROOK || p.type == PieceType.QUEEN)) return true
                    break
                }
                nr += dr
                nc += dc
            }
        }
        for ((dr, dc) in listOf(-1 to -1, -1 to 1, 1 to -1, 1 to 1)) {
            var nr = sq.row + dr
            var nc = sq.col + dc
            while (nr in 0..7 && nc in 0..7) {
                val p = grid[nr][nc]
                if (p != null) {
                    if (p.side == bySide && (p.type == PieceType.BISHOP || p.type == PieceType.QUEEN)) return true
                    break
                }
                nr += dr
                nc += dc
            }
        }
        return false
    }

    private fun addRays(
        grid: Array<Array<Piece?>>,
        from: Square,
        side: Side,
        enemy: Side,
        dirs: List<Pair<Int, Int>>,
        out: MutableList<Move>
    ) {
        for ((dr, dc) in dirs) {
            var nr = from.row + dr
            var nc = from.col + dc
            while (nr in 0..7 && nc in 0..7) {
                val p = grid[nr][nc]
                if (p == null) {
                    out.add(Move(from, Square(nr, nc)))
                } else {
                    if (p.side == enemy) out.add(Move(from, Square(nr, nc)))
                    break
                }
                nr += dr
                nc += dc
            }
        }
    }
}
