# Chess Alomgir Tournament

এটি Android-এর জন্য Kotlin + Jetpack Compose-এ তৈরি একটি প্রাথমিক অফলাইন দাবা ও ৪-জনের রাউন্ড-রবিন টুর্নামেন্ট প্রোটোটাইপ।

## বর্তমান সুবিধা
- একই ফোনে দুই পক্ষের চাল দিয়ে দাবা খেলা
- বৈধ চাল যাচাই, Check, Checkmate ও Stalemate
- Castling, En Passant ও Pawn Promotion
- প্রতি চালের জন্য ৩০ সেকেন্ডের টাইমার
- চারজন খেলোয়াড়ের ছয়টি Round Robin ম্যাচ
- খেলোয়াড়ের নাম সম্পাদনা এবং স্থানীয় Standings/পয়েন্ট

## এখনো যা নেই
এটি এখনো অনলাইন মাল্টিপ্লেয়ার, লগইন/রেজিস্ট্রেশন, Firebase, অনলাইন টুর্নামেন্ট, সার্ভার-সিঙ্ক বা Play Store-প্রস্তুত পূর্ণাঙ্গ অ্যাপ নয়। Standings ও ম্যাচের ডেটা ডিভাইসের অ্যাপ-সেশনে থাকে; স্থায়ীভাবে সংরক্ষণের ব্যবস্থা নেই।

## APK তৈরি
GitHub-এ প্রজেক্টের সব ফাইল (ZIP ফাইলটি একা নয়, ZIP-এর ভেতরের ফোল্ডার ও ফাইলগুলো) `main` branch-এ আপলোড করুন। এরপর **Actions → Build Debug APK** চালান। সফল হলে `chess-alomgir-tournament-debug-apk` নামে Artifact পাওয়া যাবে। সেটি ডাউনলোড করে ZIP থেকে APK বের করে Android ফোনে ইনস্টল করুন।

Workflow Gradle 9.6.0 ও JDK 17 সেট করে। Android SDK platform 36 এবং প্রয়োজনীয় build tools GitHub runner-এ ইনস্টল/গ্রহণ করতে হবে।

## Package
`com.chessalomgir.tournament`
