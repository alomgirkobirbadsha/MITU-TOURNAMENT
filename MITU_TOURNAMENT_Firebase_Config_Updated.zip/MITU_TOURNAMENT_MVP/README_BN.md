# MITU TOURNAMENT — Android MVP

এই ZIP-এ MITU TOURNAMENT-এর প্রথম সংস্করণের Android Studio প্রজেক্ট দেওয়া হয়েছে।

## এই সংস্করণে রাখা হয়েছে

- ইমেইল ও পাসওয়ার্ড দিয়ে রেজিস্ট্রেশন
- ইমেইল ও পাসওয়ার্ড দিয়ে লগইন
- Firebase-এ খেলোয়াড়ের প্রোফাইল সংরক্ষণ
- রেজিস্টার্ড ইমেইল দিয়ে অন্য খেলোয়াড়কে চ্যালেঞ্জ পাঠানো
- চ্যালেঞ্জ গ্রহণ বা প্রত্যাখ্যান
- Firestore-এর মাধ্যমে দুই খেলোয়াড়ের লাইভ চাল আদান-প্রদান
- দাবার বোর্ড, বৈধ চাল যাচাই, কাস্টলিং, এন-পাসাঁ, কুইন প্রমোশন, চেক, চেকমেট ও স্টেলমেট

## এই সংস্করণে নেই

- কোনো টাকা Wallet নেই
- কোনো Entry Fee নেই
- পেমেন্ট নেই
- কয়েন/ডায়মন্ড এখনো চালু করা হয়নি
- টুর্নামেন্ট, রেটিং, ঘড়ি, ড্র অফার, রিজাইন ও পূর্ণাঙ্গ গেম হিস্ট্রি UI এখনো তৈরি হয়নি

## Firebase চালু করার নিয়ম

1. Firebase Console-এ `mitu-tournament` প্রজেক্ট খুলুন।
2. Authentication → Sign-in method থেকে Email/Password চালু করুন।
3. Cloud Firestore-এ `(default)` database তৈরি/নিশ্চিত করুন।
4. ZIP-এর `firestore.rules` ফাইলের নিয়ম Firestore Rules-এ Publish করুন।
5. `app/google-services.json` ফাইলটি সঠিক প্রজেক্ট ও Android package-এর জন্য দেওয়া আছে: `com.mitutournament.app`।

## অ্যাপ চালানো

Android Studio-তে ZIP Extract করে `MITU TOURNAMENT` প্রজেক্ট ফোল্ডার Open করুন। Gradle Sync সম্পন্ন হলে Android ফোনে Run করুন।

**সতর্কতা:** এই ZIP-এ Gradle Wrapper JAR নেই এবং এখানে Android SDK দিয়ে APK Build পরীক্ষা করা যায়নি। তাই এটিকে সম্পূর্ণ পরীক্ষিত APK বা Play Store-ready সংস্করণ বলা হচ্ছে না। প্রথমে দুইটি আলাদা Firebase test account দিয়ে Registration, Login, Challenge, Accept/Reject এবং দুই ফোনে চাল আদান-প্রদান পরীক্ষা করতে হবে।

প্রতিযোগিতামূলক ব্যবহারের আগে চালের বৈধতা সার্ভার-সাইড Cloud Functions দিয়ে যাচাই করা প্রয়োজন; শুধু ফোনের কোডের ওপর নির্ভর করলে পরিবর্তিত অ্যাপ দিয়ে ভুল চাল পাঠানোর ঝুঁকি থাকে।
