package com.mitutournament.app

import com.mitutournament.app.chess.ChessPosition
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Test

class ChessPositionTest {
    @Test fun openingPositionAllowsE4AndAlternatesTurn() {
        val start = ChessPosition.fromFen(ChessPosition.START_FEN)
        val next = start.move(ChessPosition.squareIndex("e2"), ChessPosition.squareIndex("e4"))
        assertNotNull(next)
        assertEquals(false, next!!.whiteToMove)
        assertEquals('P', next.pieceAt(ChessPosition.squareIndex("e4")))
    }

    @Test fun pawnCannotMoveThreeSquares() {
        val start = ChessPosition.fromFen(ChessPosition.START_FEN)
        assertNull(start.move(ChessPosition.squareIndex("e2"), ChessPosition.squareIndex("e5")))
    }

    @Test fun openingPositionIsActive() {
        assertEquals("active", ChessPosition.fromFen(ChessPosition.START_FEN).status())
    }
}
