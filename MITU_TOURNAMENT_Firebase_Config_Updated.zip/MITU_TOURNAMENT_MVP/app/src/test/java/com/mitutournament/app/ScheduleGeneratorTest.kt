package com.mitutournament.app

import com.mitutournament.app.domain.ScheduleGenerator
import com.mitutournament.app.model.MatchStatus
import com.mitutournament.app.model.Team
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class ScheduleGeneratorTest {

    private fun sampleTeams(count: Int): List<Team> =
        (1..count).map { i ->
            Team(
                id = "team_$i",
                userId = "user_1",
                tournamentId = "tourney_1",
                name = "Team $i",
                tag = "T$i",
                seed = i.toLong()
            )
        }

    @Test
    fun `single elimination 4 teams creates 3 linked matches`() {
        val schedule = ScheduleGenerator.generateSingleElimination("user_1", "tourney_1", sampleTeams(4))
        assertEquals(3, schedule.matches.size)
        assertEquals(0L, schedule.preCompletedCount)

        val round1 = schedule.matches.filter { it.roundNumber == 1L }
        val finalMatch = schedule.matches.single { it.roundNumber == 2L }
        assertEquals(2, round1.size)
        assertEquals("Semifinals", round1[0].roundName)
        assertEquals("Final", finalMatch.roundName)
        assertEquals(finalMatch.id, round1[0].nextMatchId)
        assertEquals("A", round1[0].nextMatchSlot)
        assertEquals("B", round1[1].nextMatchSlot)
    }

    @Test
    fun `single elimination 3 teams auto-advances seed 1 bye to final`() {
        val schedule = ScheduleGenerator.generateSingleElimination("user_1", "tourney_1", sampleTeams(3))
        assertEquals(3, schedule.matches.size)
        assertEquals(1L, schedule.preCompletedCount)

        val byeMatch = schedule.matches.single { it.byeMatch }
        assertEquals(MatchStatus.COMPLETED.name, byeMatch.status)
        assertEquals("team_1", byeMatch.winnerTeamId)

        val finalMatch = schedule.matches.single { it.roundNumber == 2L }
        assertEquals("team_1", finalMatch.teamAId)
    }

    @Test
    fun `round robin 4 teams generates 6 unique pairings across 3 rounds`() {
        val schedule = ScheduleGenerator.generateRoundRobin("user_1", "tourney_1", sampleTeams(4))
        assertEquals(6, schedule.matches.size)
        val pairings = schedule.matches.map { setOf(it.teamAId, it.teamBId) }.toSet()
        assertEquals(6, pairings.size)
    }

    @Test
    fun `standings computes points and goal difference accurately`() {
        val teams = sampleTeams(2)
        val schedule = ScheduleGenerator.generateRoundRobin("user_1", "tourney_1", teams)
        val completedMatch = schedule.matches.first().copy(
            scoreA = 3L,
            scoreB = 1L,
            status = MatchStatus.COMPLETED.name,
            winnerTeamId = "team_1",
            winnerTeamName = "Team 1"
        )
        val standings = ScheduleGenerator.computeStandings(teams, listOf(completedMatch))
        assertEquals(2, standings.size)
        assertEquals("team_1", standings[0].team.id)
        assertEquals(3, standings[0].points)
        assertEquals(2, standings[0].diff)
        assertEquals("team_2", standings[1].team.id)
        assertEquals(0, standings[1].points)
        assertTrue(standings[1].diff == -2)
    }
}
