package com.mitutournament.app.model

import androidx.annotation.Keep
import com.google.firebase.Timestamp
import com.google.firebase.firestore.DocumentId
import com.google.firebase.firestore.IgnoreExtraProperties
import com.google.firebase.firestore.ServerTimestamp

enum class TournamentFormat(val label: String) {
    SINGLE_ELIMINATION("Single Elimination"),
    ROUND_ROBIN("Round Robin");

    companion object {
        fun fromRaw(raw: String): TournamentFormat =
            entries.firstOrNull { it.name == raw } ?: SINGLE_ELIMINATION
    }
}

enum class TournamentStatus(val label: String) {
    DRAFT("Draft"),
    ACTIVE("Active"),
    COMPLETED("Completed");

    companion object {
        fun fromRaw(raw: String): TournamentStatus =
            entries.firstOrNull { it.name == raw } ?: DRAFT
    }
}

enum class MatchStatus(val label: String) {
    UPCOMING("Upcoming"),
    LIVE("Live"),
    COMPLETED("Final");

    companion object {
        fun fromRaw(raw: String): MatchStatus =
            entries.firstOrNull { it.name == raw } ?: UPCOMING
    }
}

@Keep
@IgnoreExtraProperties
data class Tournament(
    @DocumentId val id: String = "",
    val userId: String = "",
    val name: String = "",
    val sport: String = "",
    val format: String = TournamentFormat.SINGLE_ELIMINATION.name,
    val status: String = TournamentStatus.DRAFT.name,
    val venue: String? = null,
    val teamCount: Long = 0L,
    val completedMatchCount: Long = 0L,
    val totalMatchCount: Long = 0L,
    val championName: String? = null,
    @ServerTimestamp val createdAt: Timestamp? = null,
    @ServerTimestamp val updatedAt: Timestamp? = null
) {
    val formatEnum: TournamentFormat get() = TournamentFormat.fromRaw(format)
    val statusEnum: TournamentStatus get() = TournamentStatus.fromRaw(status)
}

@Keep
@IgnoreExtraProperties
data class Team(
    @DocumentId val id: String = "",
    val userId: String = "",
    val tournamentId: String = "",
    val name: String = "",
    val tag: String = "",
    val captain: String? = null,
    val seed: Long = 1L,
    @ServerTimestamp val createdAt: Timestamp? = null,
    @ServerTimestamp val updatedAt: Timestamp? = null
)

@Keep
@IgnoreExtraProperties
data class Match(
    @DocumentId val id: String = "",
    val userId: String = "",
    val tournamentId: String = "",
    val roundNumber: Long = 1L,
    val roundName: String = "",
    val matchOrder: Long = 0L,
    val teamAId: String? = null,
    val teamAName: String = "TBD",
    val teamATag: String = "TBD",
    val teamBId: String? = null,
    val teamBName: String = "TBD",
    val teamBTag: String = "TBD",
    val scoreA: Long = 0L,
    val scoreB: Long = 0L,
    val status: String = MatchStatus.UPCOMING.name,
    val winnerTeamId: String? = null,
    val winnerTeamName: String? = null,
    val nextMatchId: String? = null,
    val nextMatchSlot: String? = null,
    val byeMatch: Boolean = false,
    @ServerTimestamp val createdAt: Timestamp? = null,
    @ServerTimestamp val updatedAt: Timestamp? = null
) {
    val statusEnum: MatchStatus get() = MatchStatus.fromRaw(status)
    val isPlayable: Boolean
        get() = !byeMatch && !teamAId.isNullOrBlank() && !teamBId.isNullOrBlank()
}

data class StandingRow(
    val rank: Int,
    val team: Team,
    val played: Int,
    val won: Int,
    val drawn: Int,
    val lost: Int,
    val scoredFor: Int,
    val scoredAgainst: Int,
    val points: Int
) {
    val diff: Int get() = scoredFor - scoredAgainst
}

sealed interface UiState<out T> {
    data object Loading : UiState<Nothing>
    data class Success<T>(val data: T) : UiState<T>
    data class Error(val message: String) : UiState<Nothing>
}
