package com.mitutournament.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.FirebaseUser
import com.mitutournament.app.ui.screens.AuthScreen
import com.mitutournament.app.ui.screens.GameScreen
import com.mitutournament.app.ui.screens.HomeScreen
import com.mitutournament.app.ui.theme.MituTournamentTheme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { MituTournamentTheme { MituApp() } }
    }
}

@Composable
private fun MituApp() {
    var user by remember { mutableStateOf<FirebaseUser?>(FirebaseAuth.getInstance().currentUser) }
    var gameId by remember { mutableStateOf<String?>(null) }
    DisposableEffect(Unit) {
        val listener = FirebaseAuth.AuthStateListener { user = it.currentUser }
        FirebaseAuth.getInstance().addAuthStateListener(listener)
        onDispose { FirebaseAuth.getInstance().removeAuthStateListener(listener) }
    }
    val current = user
    when {
        current == null -> AuthScreen(onAuthSuccess = { user = FirebaseAuth.getInstance().currentUser })
        gameId != null -> GameScreen(gameId = gameId!!, uid = current.uid, onBack = { gameId = null })
        else -> HomeScreen(
            user = current,
            onSignOut = { gameId = null; FirebaseAuth.getInstance().signOut() },
            onOpenGame = { gameId = it }
        )
    }
}
