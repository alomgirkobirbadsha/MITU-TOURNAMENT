package com.mitutournament.app.data

import com.google.firebase.Timestamp
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.UserProfileChangeRequest
import com.google.firebase.firestore.DocumentSnapshot
import com.google.firebase.firestore.FieldValue
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.ListenerRegistration
import com.google.firebase.firestore.SetOptions
import com.mitutournament.app.chess.ChessPosition
import kotlinx.coroutines.tasks.await
import java.util.UUID

data class ChallengeItem(
    val id: String, val fromUid: String, val fromName: String, val fromEmail: String,
    val toUid: String, val toName: String, val status: String, val gameId: String?, val createdAt: Timestamp?
) {
    val opponentName: String get() = if (status == "pending" && toUid == FirebaseAuth.getInstance().currentUser?.uid) fromName else toName
    companion object {
        fun from(doc: DocumentSnapshot) = ChallengeItem(
            id = doc.id,
            fromUid = doc.getString("fromUid").orEmpty(),
            fromName = doc.getString("fromName").orEmpty(),
            fromEmail = doc.getString("fromEmail").orEmpty(),
            toUid = doc.getString("toUid").orEmpty(),
            toName = doc.getString("toName").orEmpty(),
            status = doc.getString("status").orEmpty(),
            gameId = doc.getString("gameId"),
            createdAt = doc.getTimestamp("createdAt")
        )
    }
}

data class LiveGame(
    val id: String, val whiteUid: String, val blackUid: String, val whiteName: String,
    val blackName: String, val fen: String, val turnUid: String, val status: String,
    val winnerUid: String?
) {
    companion object {
        fun from(doc: DocumentSnapshot) = LiveGame(
            id = doc.id, whiteUid = doc.getString("whiteUid").orEmpty(), blackUid = doc.getString("blackUid").orEmpty(),
            whiteName = doc.getString("whiteName").orEmpty(), blackName = doc.getString("blackName").orEmpty(),
            fen = doc.getString("fen") ?: ChessPosition.START_FEN, turnUid = doc.getString("turnUid").orEmpty(),
            status = doc.getString("status").orEmpty(), winnerUid = doc.getString("winnerUid")
        )
    }
}

class MituRepository(
    private val auth: FirebaseAuth = FirebaseAuth.getInstance(),
    private val db: FirebaseFirestore = FirebaseFirestore.getInstance()
) {
    suspend fun register(name: String, email: String, password: String) {
        val cleanName = name.trim()
        val cleanEmail = email.trim().lowercase()
        require(cleanName.length in 2..30) { "নাম ২ থেকে ৩০ অক্ষরের মধ্যে লিখুন" }
        require(EMAIL_PATTERN.matches(cleanEmail)) { "সঠিক ইমেইল ঠিকানা লিখুন" }
        require(password.length >= 6) { "পাসওয়ার্ড কমপক্ষে ৬ অক্ষরের হতে হবে" }

        val result = auth.createUserWithEmailAndPassword(cleanEmail, password).await()
        val newUser = result.user ?: error("অ্যাকাউন্ট তৈরি হয়েছে, কিন্তু User ID পাওয়া যায়নি")
        val uid = newUser.uid
        try {
            newUser.updateProfile(UserProfileChangeRequest.Builder().setDisplayName(cleanName).build()).await()
            db.collection("users").document(uid).set(
                mapOf(
                    "uid" to uid,
                    "displayName" to cleanName,
                    "email" to cleanEmail,
                    "role" to "player",
                    "rating" to 1200,
                    "wins" to 0,
                    "losses" to 0,
                    "draws" to 0,
                    "createdAt" to FieldValue.serverTimestamp()
                )
            ).await()
        } catch (e: Exception) {
            // Avoid leaving a half-created session active. The account can sign in again;
            // login() repairs a missing profile document if the Firestore write previously failed.
            auth.signOut()
            throw e
        }
    }

    suspend fun login(email: String, password: String) {
        val cleanEmail = email.trim().lowercase()
        require(EMAIL_PATTERN.matches(cleanEmail)) { "সঠিক ইমেইল ঠিকানা লিখুন" }
        require(password.isNotEmpty()) { "পাসওয়ার্ড লিখুন" }
        val result = auth.signInWithEmailAndPassword(cleanEmail, password).await()
        val user = result.user ?: error("লগইন করা যায়নি")
        val profileRef = db.collection("users").document(user.uid)
        val profile = profileRef.get().await()
        if (!profile.exists()) {
            // Recover accounts created successfully by Firebase Auth when a previous
            // profile write was interrupted by a network/rules error.
            profileRef.set(
                mapOf(
                    "uid" to user.uid,
                    "displayName" to (user.displayName?.takeIf { it.isNotBlank() } ?: cleanEmail.substringBefore("@")),
                    "email" to cleanEmail,
                    "role" to "player",
                    "rating" to 1200,
                    "wins" to 0,
                    "losses" to 0,
                    "draws" to 0,
                    "createdAt" to FieldValue.serverTimestamp()
                ), SetOptions.merge()
            ).await()
        }
    }

    suspend fun sendPasswordReset(email: String) {
        val cleanEmail = email.trim().lowercase()
        require(EMAIL_PATTERN.matches(cleanEmail)) { "পাসওয়ার্ড রিসেটের জন্য সঠিক ইমেইল লিখুন" }
        auth.sendPasswordResetEmail(cleanEmail).await()
    }

    private companion object {
        val EMAIL_PATTERN = Regex("^[A-Z0-9._%+-]+@[A-Z0-9.-]+\\.[A-Z]{2,}$", RegexOption.IGNORE_CASE)
    }

    suspend fun sendChallenge(fromUid: String, fromName: String, fromEmail: String, targetEmail: String) {
        val email = targetEmail.trim().lowercase()
        require(email.isNotBlank()) { "প্রতিপক্ষের ইমেইল লিখুন" }
        require(email != fromEmail.lowercase()) { "নিজেকে চ্যালেঞ্জ পাঠানো যাবে না" }
        val result = db.collection("users").whereEqualTo("email", email).limit(1).get().await()
        val target = result.documents.firstOrNull() ?: error("এই ইমেইলে কোনো MITU TOURNAMENT অ্যাকাউন্ট পাওয়া যায়নি")
        val toUid = target.getString("uid") ?: target.id
        val toName = target.getString("displayName") ?: email
        val id = UUID.randomUUID().toString()
        db.collection("challenges").document(id).set(
            mapOf(
                "fromUid" to fromUid, "fromName" to fromName, "fromEmail" to fromEmail.lowercase(),
                "toUid" to toUid, "toName" to toName, "participants" to listOf(fromUid, toUid),
                "status" to "pending", "createdAt" to FieldValue.serverTimestamp(), "updatedAt" to FieldValue.serverTimestamp()
            )
        ).await()
    }

    fun listenChallenges(uid: String, onChange: (List<ChallengeItem>, String?) -> Unit): ListenerRegistration =
        db.collection("challenges").whereArrayContains("participants", uid).addSnapshotListener { snap, error ->
            if (error != null) { onChange(emptyList(), error.localizedMessage); return@addSnapshotListener }
            val items = snap?.documents.orEmpty().map { ChallengeItem.from(it) }.sortedByDescending { it.createdAt?.seconds ?: 0L }
            onChange(items, null)
        }

    suspend fun respondToChallenge(challengeId: String, accept: Boolean): String? {
        val challengeRef = db.collection("challenges").document(challengeId)
        if (!accept) {
            db.runTransaction { tx ->
                val snap = tx.get(challengeRef)
                check(snap.getString("toUid") == auth.currentUser?.uid && snap.getString("status") == "pending") { "এই চ্যালেঞ্জটি আর গ্রহণ করা যাবে না" }
                tx.update(challengeRef, mapOf("status" to "rejected", "updatedAt" to FieldValue.serverTimestamp()))
                true
            }.await()
            return null
        }
        val gameRef = db.collection("games").document()
        return db.runTransaction { tx ->
            val snap = tx.get(challengeRef)
            check(snap.getString("toUid") == auth.currentUser?.uid && snap.getString("status") == "pending") { "এই চ্যালেঞ্জটি আর গ্রহণ করা যাবে না" }
            val fromUid = snap.getString("fromUid") ?: error("চ্যালেঞ্জ প্রেরক পাওয়া যায়নি")
            val toUid = snap.getString("toUid") ?: error("চ্যালেঞ্জ গ্রহণকারী পাওয়া যায়নি")
            val fromName = snap.getString("fromName").orEmpty()
            val toName = snap.getString("toName").orEmpty()
            tx.update(challengeRef, mapOf("status" to "accepted", "gameId" to gameRef.id, "updatedAt" to FieldValue.serverTimestamp()))
            tx.set(gameRef, mapOf(
                "challengeId" to challengeId, "whiteUid" to fromUid, "blackUid" to toUid,
                "whiteName" to fromName, "blackName" to toName,
                "participants" to listOf(fromUid, toUid), "fen" to ChessPosition.START_FEN,
                "turnUid" to fromUid, "status" to "active", "moveHistory" to emptyList<Map<String, Any>>(),
                "createdAt" to FieldValue.serverTimestamp(), "updatedAt" to FieldValue.serverTimestamp()
            ))
            gameRef.id
        }.await()
    }

    fun listenGame(gameId: String, onChange: (LiveGame?, String?) -> Unit): ListenerRegistration =
        db.collection("games").document(gameId).addSnapshotListener { snap, error ->
            if (error != null) onChange(null, error.localizedMessage)
            else if (snap != null && snap.exists()) onChange(LiveGame.from(snap), null)
            else onChange(null, "গেমটি পাওয়া যায়নি")
        }

    suspend fun makeMove(game: LiveGame, uid: String, from: Int, to: Int) {
        val ref = db.collection("games").document(game.id)
        db.runTransaction { tx ->
            val snap = tx.get(ref)
            check(snap.getString("status") == "active") { "এই ম্যাচটি শেষ হয়েছে" }
            check(snap.getString("turnUid") == uid) { "এখন আপনার চাল দেওয়ার পালা নয়" }
            val fen = snap.getString("fen") ?: ChessPosition.START_FEN
            val position = ChessPosition.fromFen(fen)
            val next = position.move(from, to) ?: error("এই চালটি বৈধ নয়")
            val nextStatus = next.status()
            val whiteUid = snap.getString("whiteUid").orEmpty()
            val blackUid = snap.getString("blackUid").orEmpty()
            val moveHistory = (snap.get("moveHistory") as? List<*>)?.toMutableList() ?: mutableListOf()
            moveHistory.add(mapOf("from" to ChessPosition.squareName(from), "to" to ChessPosition.squareName(to), "byUid" to uid, "at" to Timestamp.now()))
            val updates = mutableMapOf<String, Any>(
                "fen" to next.toFen(), "moveHistory" to moveHistory,
                "updatedAt" to FieldValue.serverTimestamp()
            )
            if (nextStatus == "checkmate") {
                updates["status"] = "completed"; updates["winnerUid"] = uid; updates["result"] = "checkmate"; updates["turnUid"] = ""
            } else if (nextStatus == "stalemate") {
                updates["status"] = "completed"; updates["winnerUid"] = ""; updates["result"] = "draw"; updates["turnUid"] = ""
            } else {
                updates["turnUid"] = if (next.whiteToMove) whiteUid else blackUid
            }
            tx.update(ref, updates)
            true
        }.await()
    }
}
