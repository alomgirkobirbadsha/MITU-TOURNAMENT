package com.mitutournament.app.chess

/** Standard chess move validation, check detection, castling, en-passant and queen promotion. */
class ChessPosition private constructor(
    private val b: CharArray, var whiteToMove: Boolean, private var rights: String,
    private var ep: Int, private var half: Int, private var full: Int
) {
    fun pieceAt(i: Int) = if (i in 0..63) b[i] else ' '
    fun toFen(): String {
        val rows = (0..7).joinToString("/") { r ->
            val out = StringBuilder(); var empty = 0
            for (c in 0..7) { val p=b[r*8+c]; if(p==' ') empty++ else { if(empty>0){out.append(empty);empty=0};out.append(p) } }
            if(empty>0) out.append(empty); out.toString()
        }
        return "$rows ${if(whiteToMove) "w" else "b"} ${rights.ifEmpty { "-" }} ${if(ep<0) "-" else squareName(ep)} $half $full"
    }
    fun move(from: Int, to: Int): ChessPosition? {
        if(from !in 0..63 || to !in 0..63 || from==to) return null
        val p=b[from]; if(p==' ' || white(p)!=whiteToMove || b[to].lowercaseChar()=='k' || (b[to]!=' ' && white(b[to])==white(p))) return null
        if(!pseudo(from,to,p)) return null
        val n=copy(); n.apply(from,to)
        if(n.inCheck(whiteToMove)) return null
        return n
    }
    fun status(): String {
        var any=false
        loop@ for(f in 0..63) if(b[f]!=' ' && white(b[f])==whiteToMove) for(t in 0..63) if(move(f,t)!=null){any=true;break@loop}
        return if(any) if(inCheck(whiteToMove)) "check" else "active" else if(inCheck(whiteToMove)) "checkmate" else "stalemate"
    }
    private fun copy()=ChessPosition(b.copyOf(),whiteToMove,rights,ep,half,full)
    private fun pseudo(f:Int,t:Int,p:Char):Boolean {
        val fr=f/8;val fc=f%8;val tr=t/8;val tc=t%8;val dr=tr-fr;val dc=tc-fc;val target=b[t]
        return when(p.lowercaseChar()) {
            'p' -> { val d=if(white(p))-1 else 1; val start=if(white(p))6 else 1
                (dc==0 && dr==d && target==' ') || (dc==0 && dr==2*d && fr==start && target==' ' && b[(fr+d)*8+fc]==' ') || (kotlin.math.abs(dc)==1 && dr==d && (target!=' ' || t==ep)) }
            'n' -> (kotlin.math.abs(dr)==2 && kotlin.math.abs(dc)==1)||(kotlin.math.abs(dr)==1&&kotlin.math.abs(dc)==2)
            'b' -> kotlin.math.abs(dr)==kotlin.math.abs(dc)&&pathClear(fr,fc,tr,tc)
            'r' -> (dr==0||dc==0)&&pathClear(fr,fc,tr,tc)
            'q' -> ((dr==0||dc==0)||kotlin.math.abs(dr)==kotlin.math.abs(dc))&&pathClear(fr,fc,tr,tc)
            'k' -> if(kotlin.math.abs(dr)<=1&&kotlin.math.abs(dc)<=1) true else castle(f,t,p)
            else -> false
        }
    }
    private fun pathClear(fr:Int,fc:Int,tr:Int,tc:Int):Boolean { val sr=(tr-fr).compareTo(0);val sc=(tc-fc).compareTo(0);var r=fr+sr;var c=fc+sc;while(r!=tr||c!=tc){if(b[r*8+c]!=' ')return false;r+=sr;c+=sc};return true }
    private fun castle(f:Int,t:Int,p:Char):Boolean {
        val w=white(p);val home=if(w)60 else 4;if(f!=home||inCheck(w))return false
        val ks=t==home+2;val qs=t==home-2;if(!ks&&!qs)return false
        val right=if(w){if(ks)"K" else "Q"}else{if(ks)"k" else "q"};if(!rights.contains(right))return false
        val rookAt=when{w&&ks->63;w->56;ks->7;else->0};val rook=b[rookAt]
        if(rook.lowercaseChar()!='r'||white(rook)!=w)return false
        val empty=if(ks) listOf(home+1,home+2) else listOf(home-1,home-2,home-3)
        if(empty.any{b[it]!=' '})return false
        val path=if(ks) listOf(home+1,home+2) else listOf(home-1,home-2)
        return path.none{attacked(it,!w)}
    }
    private fun apply(f:Int,t:Int) {
        val p=b[f];val captured=b[t];val w=white(p);val fr=f/8;val tr=t/8
        if(p.lowercaseChar()=='p'&&t==ep&&captured==' '&&f%8!=t%8)b[if(w)t+8 else t-8]=' '
        b[t]=p;b[f]=' '
        if(p.lowercaseChar()=='k'&&kotlin.math.abs(t-f)==2) when(t){62->{b[61]=b[63];b[63]=' '};58->{b[59]=b[56];b[56]=' '};6->{b[5]=b[7];b[7]=' '};2->{b[3]=b[0];b[0]=' '}}
        if(p=='K')rights=rights.replace("K","").replace("Q","");if(p=='k')rights=rights.replace("k","").replace("q","")
        when(f){63->rights=rights.replace("K","");56->rights=rights.replace("Q","");7->rights=rights.replace("k","");0->rights=rights.replace("q","")}
        when(t){63->rights=rights.replace("K","");56->rights=rights.replace("Q","");7->rights=rights.replace("k","");0->rights=rights.replace("q","")}
        ep=if(p.lowercaseChar()=='p'&&kotlin.math.abs(tr-fr)==2)(f+t)/2 else -1
        if(p.lowercaseChar()=='p'&&(tr==0||tr==7))b[t]=if(w)'Q' else 'q'
        half=if(p.lowercaseChar()=='p'||captured!=' ')0 else half+1;if(!w)full++
        whiteToMove=!whiteToMove
    }
    private fun inCheck(w:Boolean):Boolean { val k=if(w)'K' else 'k';val at=b.indexOf(k);return at<0||attacked(at,!w) }
    private fun attacked(s:Int,byWhite:Boolean):Boolean {
        val tr=s/8;val tc=s%8
        for(i in 0..63){val p=b[i];if(p==' '||white(p)!=byWhite)continue;val r=i/8;val c=i%8;val dr=tr-r;val dc=tc-c
            val hit=when(p.lowercaseChar()){
                'p'->dr==(if(byWhite)-1 else 1)&&kotlin.math.abs(dc)==1
                'n'->(kotlin.math.abs(dr)==2&&kotlin.math.abs(dc)==1)||(kotlin.math.abs(dr)==1&&kotlin.math.abs(dc)==2)
                'k'->kotlin.math.abs(dr)<=1&&kotlin.math.abs(dc)<=1
                'b'->kotlin.math.abs(dr)==kotlin.math.abs(dc)&&pathClear(r,c,tr,tc)
                'r'->(dr==0||dc==0)&&pathClear(r,c,tr,tc)
                'q'->((dr==0||dc==0)||kotlin.math.abs(dr)==kotlin.math.abs(dc))&&pathClear(r,c,tr,tc)
                else->false
            };if(hit)return true
        };return false
    }
    companion object {
        const val START_FEN="rnbqkbnr/pppppppp/8/8/8/8/PPPPPPPP/RNBQKBNR w KQkq - 0 1"
        private fun white(p:Char)=p.isUpperCase()
        fun squareIndex(s:String):Int {if(s.length!=2)return -1;val c=s[0].lowercaseChar()-'a';val r=s[1].digitToIntOrNull()?:return -1;return if(c in 0..7&&r in 1..8)(8-r)*8+c else -1}
        fun squareName(i:Int)="${'a'+i%8}${8-i/8}"
        fun fromFen(fen:String):ChessPosition {val x=fen.split(' ');val b=CharArray(64){' '};var i=0;for(ch in x[0])when{ch=='/'->Unit;ch.isDigit()->i+=ch.digitToInt();else->{if(i in 0..63)b[i]=ch;i++}};val ep=if(x.getOrNull(3).isNullOrBlank()||x[3]=="-")-1 else squareIndex(x[3]);return ChessPosition(b,x.getOrNull(1)!="b",x.getOrNull(2)?.takeIf{it!="-"}.orEmpty(),ep,x.getOrNull(4)?.toIntOrNull()?:0,x.getOrNull(5)?.toIntOrNull()?:1)}
    }
}
