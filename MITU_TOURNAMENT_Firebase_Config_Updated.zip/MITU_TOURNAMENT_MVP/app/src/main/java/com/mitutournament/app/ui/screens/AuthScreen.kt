package com.mitutournament.app.ui.screens

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.ui.unit.dp
import com.mitutournament.app.data.MituRepository
import kotlinx.coroutines.launch

@Composable
fun AuthScreen(onAuthSuccess: () -> Unit) {
    val repo = remember { MituRepository() }
    val scope = rememberCoroutineScope()
    var registering by remember { mutableStateOf(false) }
    var name by remember { mutableStateOf("") }
    var email by remember { mutableStateOf("") }
    var password by remember { mutableStateOf("") }
    var confirmPassword by remember { mutableStateOf("") }
    var busy by remember { mutableStateOf(false) }
    var error by remember { mutableStateOf("") }
    var notice by remember { mutableStateOf("") }

    Surface(modifier = Modifier.fillMaxSize(), color = MaterialTheme.colorScheme.background) {
        Column(
            modifier = Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(24.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            Text("♛", style = MaterialTheme.typography.displayLarge, color = MaterialTheme.colorScheme.primary)
            Text("MITU TOURNAMENT", style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold)
            Text("অনলাইন দাবা খেলুন, চ্যালেঞ্জ পাঠান", color = MaterialTheme.colorScheme.onSurfaceVariant)
            Spacer(Modifier.height(28.dp))

            if (registering) {
                OutlinedTextField(
                    value = name, onValueChange = { name = it.take(30) },
                    label = { Text("আপনার নাম") }, modifier = Modifier.fillMaxWidth(), singleLine = true
                )
                Spacer(Modifier.height(10.dp))
            }
            OutlinedTextField(
                value = email, onValueChange = { email = it.trimStart() },
                label = { Text("ইমেইল") }, modifier = Modifier.fillMaxWidth(), singleLine = true,
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Email)
            )
            Spacer(Modifier.height(10.dp))
            OutlinedTextField(
                value = password, onValueChange = { password = it },
                label = { Text("পাসওয়ার্ড (কমপক্ষে ৬ অক্ষর)") }, modifier = Modifier.fillMaxWidth(),
                singleLine = true, visualTransformation = PasswordVisualTransformation(),
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Password)
            )
            if (registering) {
                Spacer(Modifier.height(10.dp))
                OutlinedTextField(
                    value = confirmPassword, onValueChange = { confirmPassword = it },
                    label = { Text("পাসওয়ার্ড নিশ্চিত করুন") }, modifier = Modifier.fillMaxWidth(),
                    singleLine = true, visualTransformation = PasswordVisualTransformation(),
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Password)
                )
            }

            if (error.isNotBlank()) Text(error, color = MaterialTheme.colorScheme.error, modifier = Modifier.padding(top = 10.dp))
            if (notice.isNotBlank()) Text(notice, color = MaterialTheme.colorScheme.primary, modifier = Modifier.padding(top = 10.dp))
            Spacer(Modifier.height(18.dp))
            Button(
                onClick = {
                    error = ""
                    notice = ""
                    val cleanEmail = email.trim()
                    when {
                        !cleanEmail.matches(Regex("^[A-Z0-9._%+-]+@[A-Z0-9.-]+\\.[A-Z]{2,}$", RegexOption.IGNORE_CASE)) -> error = "সঠিক ইমেইল ঠিকানা লিখুন"
                        password.length < 6 -> error = "পাসওয়ার্ড কমপক্ষে ৬ অক্ষরের হতে হবে"
                        registering && name.trim().length < 2 -> error = "আপনার নাম কমপক্ষে ২ অক্ষরের লিখুন"
                        registering && password != confirmPassword -> error = "দুটি পাসওয়ার্ড মিলছে না"
                        else -> scope.launch {
                            busy = true
                            try {
                                if (registering) repo.register(name, cleanEmail, password)
                                else repo.login(cleanEmail, password)
                                onAuthSuccess()
                            } catch (e: Exception) {
                                error = e.localizedMessage ?: "অনুরোধ সম্পন্ন হয়নি। ইন্টারনেট ও Firebase সেটিংস পরীক্ষা করুন।"
                            } finally { busy = false }
                        }
                    }
                }, enabled = !busy, modifier = Modifier.fillMaxWidth()
            ) {
                if (busy) CircularProgressIndicator() else Text(if (registering) "অ্যাকাউন্ট তৈরি করুন" else "লগইন করুন")
            }
            if (!registering) {
                TextButton(enabled = !busy, onClick = {
                    error = ""; notice = ""
                    scope.launch {
                        busy = true
                        try {
                            repo.sendPasswordReset(email)
                            notice = "পাসওয়ার্ড রিসেটের লিংক আপনার ইমেইলে পাঠানো হয়েছে।"
                        } catch (e: Exception) {
                            error = e.localizedMessage ?: "রিসেট ইমেইল পাঠানো যায়নি"
                        } finally { busy = false }
                    }
                }) { Text("পাসওয়ার্ড ভুলে গেছেন?") }
            }
            TextButton(enabled = !busy, onClick = {
                registering = !registering
                error = ""
                notice = ""
                confirmPassword = ""
            }) {
                Text(if (registering) "আগে অ্যাকাউন্ট আছে? লগইন করুন" else "নতুন ব্যবহারকারী? রেজিস্ট্রেশন করুন")
            }
        }
    }
}
