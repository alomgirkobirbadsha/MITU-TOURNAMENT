package com.mitutournament.app.data

import android.content.Context
import com.mitutournament.app.R
import com.mitutournament.app.domain.ScheduleGenerator
import com.mitutournament.app.model.Match
import com.mitutournament.app.model.MatchStatus
import com.mitutournament.app.model.Team
import com.mitutournament.app.model.Tournament
import com.mitutournament.app.model.TournamentFormat
import com.mitutournament.app.model.TournamentStatus
import com.google.firebase.Firebase
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.auth
import com.google.firebase.firestore.DocumentSnapshot
import com.google.firebase.firestore.FieldValue
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.FirebaseFirestoreException
import com.google.firebase.firestore.snapshots
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.flow.emitAll
import kotlinx.coroutines.flow.flow
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.tasks.await

class TournamentRepository(
    private val db: FirebaseFirestore,
    private val auth: FirebaseAuth = Firebase.auth
) {
    constructor(context: Context) : this(
        FirebaseFirestore.getInstance(
            context.applicationContext.getString(R.string.firestore_database_id)
        )
    )

    private fun requireUserId(expectedUserId: String? = null): String {
        val uid = auth.currentUser?.uid
            ?: throw IllegalStateException("User must be signed in with Google before accessing Firestore.")
        if (expectedUserId != null) {
            check(uid == expectedUserId) { "Signed-in user changed; refusing cross-user access." }
        }
        return uid
    }

    private fun tournamentsCol(userId: String) =
        db.collection("users").document(userId).collection("tournaments")

    fun observeTournaments(userId: String): Flow<List<Tournament>> = flow {
        val uid = requireUserId(userId)
        val path = "users/$uid/tournaments"
        emitAll(
            tournamentsCol(uid)
                .snapshots()
                .map { snapshot ->
                    snapshot.toObjects(
                        Tournament::class.java,
                        DocumentSnapshot.ServerTimestampBehavior.ESTIMATE
                    ).sortedByDescending { it.updatedAt ?: it.createdAt }
                }
                .catch { error ->
                    logStreamErrorIfAuthenticated(error, OperationType.LIST, path, uid)
                    throw error
                }
        )
    }

    fun observeTournament(userId: String, tournamentId: String): Flow<Tournament?> = flow {
        val uid = requireUserId(userId)
        val path = "users/$uid/tournaments/$tournamentId"
        emitAll(
            tournamentsCol(uid).document(tournamentId)
                .snapshots()
                .map { snapshot ->
                    snapshot.toObject(
                        Tournament::class.java,
                        DocumentSnapshot.ServerTimestampBehavior.ESTIMATE
                    )
                }
                .catch { error ->
                    logStreamErrorIfAuthenticated(error, OperationType.GET, path, uid)
                    throw error
                }
        )
    }

    fun observeTeams(userId: String, tournamentId: String): Flow<List<Team>> = flow {
        val uid = requireUserId(userId)
        val path = "users/$uid/tournaments/$tournamentId/teams"
        emitAll(
            tournamentsCol(uid).document(tournamentId).collection("teams")
                .snapshots()
                .map { snapshot ->
                    snapshot.toObjects(
                        Team::class.java,
                        DocumentSnapshot.ServerTimestampBehavior.ESTIMATE
                    ).sortedBy { it.seed }
                }
                .catch { error ->
                    logStreamErrorIfAuthenticated(error, OperationType.LIST, path, uid)
                    throw error
                }
        )
    }

    fun observeMatches(userId: String, tournamentId: String): Flow<List<Match>> = flow {
        val uid = requireUserId(userId)
        val path = "users/$uid/tournaments/$tournamentId/matches"
        emitAll(
            tournamentsCol(uid).document(tournamentId).collection("matches")
                .snapshots()
                .map { snapshot ->
                    snapshot.toObjects(
                        Match::class.java,
                        DocumentSnapshot.ServerTimestampBehavior.ESTIMATE
                    ).sortedWith(compareBy<Match> { it.roundNumber }.thenBy { it.matchOrder })
                }
                .catch { error ->
                    logStreamErrorIfAuthenticated(error, OperationType.LIST, path, uid)
                    throw error
                }
        )
    }

    suspend fun createTournament(
        userId: String,
        name: String,
        sport: String,
        format: TournamentFormat,
        venue: String?
    ): Result<String> {
        val trimmedName = name.trim()
        val trimmedSport = sport.trim()
        val trimmedVenue = venue?.trim()?.takeIf { it.isNotEmpty() }
        var docPath = "users/$userId/tournaments"
        return try {
            require(trimmedName.length in 2..60) { "Tournament name must be 2–60 characters." }
            require(trimmedSport.length in 1..30) { "Sport or discipline must be 1–30 characters." }
            require(trimmedVenue == null || trimmedVenue.length <= 80) { "Venue must be 80 characters or fewer." }
            val uid = requireUserId(userId)
            val docRef = tournamentsCol(uid).document()
            docPath = docRef.path
            val payload = mapOf(
                "userId" to uid,
                "name" to trimmedName,
                "sport" to trimmedSport,
                "format" to format.name,
                "status" to TournamentStatus.DRAFT.name,
                "venue" to trimmedVenue,
                "teamCount" to 0L,
                "completedMatchCount" to 0L,
                "totalMatchCount" to 0L,
                "createdAt" to FieldValue.serverTimestamp(),
                "updatedAt" to FieldValue.serverTimestamp()
            ).filterValues { it != null }
            docRef.set(payload).await()
            Result.success(docRef.id)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.CREATE, docPath)
            Result.failure(e)
        }
    }

    suspend fun deleteTournament(userId: String, tournamentId: String): Result<Unit> {
        val docPath = "users/$userId/tournaments/$tournamentId"
        return try {
            val uid = requireUserId(userId)
            val tRef = tournamentsCol(uid).document(tournamentId)
            val teamsSnap = tRef.collection("teams").get().await()
            val matchesSnap = tRef.collection("matches").get().await()

            val allRefs = teamsSnap.documents.map { it.reference } +
                matchesSnap.documents.map { it.reference } +
                listOf(tRef)

            // Commit in chunks of 450 to respect Firestore 500-op WriteBatch limit
            allRefs.chunked(450).forEach { chunk ->
                val batch = db.batch()
                chunk.forEach { batch.delete(it) }
                batch.commit().await()
            }
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.DELETE, docPath)
            Result.failure(e)
        }
    }

    suspend fun addTeam(
        userId: String,
        tournamentId: String,
        name: String,
        tag: String,
        captain: String?,
        nextSeed: Long
    ): Result<Unit> {
        val trimmedName = name.trim()
        val trimmedTag = tag.trim().uppercase()
        val trimmedCaptain = captain?.trim()?.takeIf { it.isNotEmpty() }
        var docPath = "users/$userId/tournaments/$tournamentId/teams"
        return try {
            require(trimmedName.length in 1..40) { "Team name must be 1–40 characters." }
            require(trimmedTag.length in 1..6) { "Team tag must be 1–6 characters." }
            require(trimmedCaptain == null || trimmedCaptain.length <= 40) { "Captain note must be 40 characters or fewer." }
            require(nextSeed in 1L..64L) { "Maximum 64 teams supported." }

            val uid = requireUserId(userId)
            val tRef = tournamentsCol(uid).document(tournamentId)
            val teamRef = tRef.collection("teams").document()
            docPath = teamRef.path

            val batch = db.batch()
            val teamPayload = mapOf(
                "userId" to uid,
                "tournamentId" to tournamentId,
                "name" to trimmedName,
                "tag" to trimmedTag,
                "captain" to trimmedCaptain,
                "seed" to nextSeed,
                "createdAt" to FieldValue.serverTimestamp(),
                "updatedAt" to FieldValue.serverTimestamp()
            ).filterValues { it != null }
            batch.set(teamRef, teamPayload)
            batch.update(
                tRef,
                mapOf(
                    "teamCount" to FieldValue.increment(1L),
                    "updatedAt" to FieldValue.serverTimestamp()
                )
            )
            batch.commit().await()
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.CREATE, docPath)
            Result.failure(e)
        }
    }

    suspend fun addSampleTeams(
        userId: String,
        tournamentId: String,
        existingCount: Int
    ): Result<Unit> {
        val samples = listOf(
            Triple("Apex Falcons", "AF", "Maya Lin"),
            Triple("Nova Knights", "NK", "Tariq"),
            Triple("Iron Wolves", "IW", "Soren"),
            Triple("Solar Titans", "ST", "Elena")
        )
        val docPath = "users/$userId/tournaments/$tournamentId/teams"
        return try {
            val uid = requireUserId(userId)
            val tRef = tournamentsCol(uid).document(tournamentId)
            val available = (64 - existingCount).coerceAtMost(samples.size)
            require(available > 0) { "Maximum 64 teams reached." }

            val batch = db.batch()
            samples.take(available).forEachIndexed { idx, (name, tag, captain) ->
                val teamRef = tRef.collection("teams").document()
                val payload = mapOf(
                    "userId" to uid,
                    "tournamentId" to tournamentId,
                    "name" to name,
                    "tag" to tag,
                    "captain" to captain,
                    "seed" to (existingCount + idx + 1).toLong(),
                    "createdAt" to FieldValue.serverTimestamp(),
                    "updatedAt" to FieldValue.serverTimestamp()
                )
                batch.set(teamRef, payload)
            }
            batch.update(
                tRef,
                mapOf(
                    "teamCount" to (existingCount + available).toLong(),
                    "updatedAt" to FieldValue.serverTimestamp()
                )
            )
            batch.commit().await()
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.WRITE, docPath)
            Result.failure(e)
        }
    }

    suspend fun removeTeam(
        userId: String,
        tournamentId: String,
        teamId: String,
        currentTeamCount: Long
    ): Result<Unit> {
        val docPath = "users/$userId/tournaments/$tournamentId/teams/$teamId"
        return try {
            val uid = requireUserId(userId)
            val tRef = tournamentsCol(uid).document(tournamentId)
            val teamRef = tRef.collection("teams").document(teamId)
            val batch = db.batch()
            batch.delete(teamRef)
            batch.update(
                tRef,
                mapOf(
                    "teamCount" to (currentTeamCount - 1L).coerceAtLeast(0L),
                    "updatedAt" to FieldValue.serverTimestamp()
                )
            )
            batch.commit().await()
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.DELETE, docPath)
            Result.failure(e)
        }
    }

    suspend fun startTournamentAndGenerateSchedule(
        userId: String,
        tournament: Tournament,
        teams: List<Team>
    ): Result<Unit> {
        val docPath = "users/$userId/tournaments/${tournament.id}"
        return try {
            require(teams.size >= 2) { "Register at least 2 teams before generating schedule." }
            require(tournament.statusEnum == TournamentStatus.DRAFT) { "Tournament is already started." }
            val uid = requireUserId(userId)
            val tRef = tournamentsCol(uid).document(tournament.id)

            val schedule = when (tournament.formatEnum) {
                TournamentFormat.SINGLE_ELIMINATION ->
                    ScheduleGenerator.generateSingleElimination(uid, tournament.id, teams)
                TournamentFormat.ROUND_ROBIN ->
                    ScheduleGenerator.generateRoundRobin(uid, tournament.id, teams)
            }

            val batch = db.batch()
            schedule.matches.forEach { match ->
                val matchRef = tRef.collection("matches").document(match.id)
                val payload = mapOf(
                    "userId" to uid,
                    "tournamentId" to tournament.id,
                    "roundNumber" to match.roundNumber,
                    "roundName" to match.roundName,
                    "matchOrder" to match.matchOrder,
                    "teamAId" to match.teamAId,
                    "teamAName" to match.teamAName,
                    "teamATag" to match.teamATag,
                    "teamBId" to match.teamBId,
                    "teamBName" to match.teamBName,
                    "teamBTag" to match.teamBTag,
                    "scoreA" to match.scoreA,
                    "scoreB" to match.scoreB,
                    "status" to match.status,
                    "winnerTeamId" to match.winnerTeamId,
                    "winnerTeamName" to match.winnerTeamName,
                    "nextMatchId" to match.nextMatchId,
                    "nextMatchSlot" to match.nextMatchSlot,
                    "byeMatch" to match.byeMatch,
                    "createdAt" to FieldValue.serverTimestamp(),
                    "updatedAt" to FieldValue.serverTimestamp()
                ).filterValues { it != null }
                batch.set(matchRef, payload)
            }

            batch.update(
                tRef,
                mapOf(
                    "status" to TournamentStatus.ACTIVE.name,
                    "teamCount" to teams.size.toLong(),
                    "totalMatchCount" to schedule.matches.size.toLong(),
                    "completedMatchCount" to schedule.preCompletedCount,
                    "updatedAt" to FieldValue.serverTimestamp()
                )
            )
            batch.commit().await()
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.WRITE, docPath)
            Result.failure(e)
        }
    }

    suspend fun updateLiveScore(
        userId: String,
        tournamentId: String,
        match: Match,
        scoreA: Long,
        scoreB: Long,
        status: MatchStatus
    ): Result<Unit> {
        val docPath = "users/$userId/tournaments/$tournamentId/matches/${match.id}"
        return try {
            require(scoreA in 0L..999L && scoreB in 0L..999L) { "Scores must be between 0 and 999." }
            require(match.statusEnum != MatchStatus.COMPLETED) { "Finalized matches are locked." }
            require(status != MatchStatus.COMPLETED) { "Use finalizeMatch to complete a match." }
            val uid = requireUserId(userId)
            val matchRef = tournamentsCol(uid).document(tournamentId)
                .collection("matches").document(match.id)
            matchRef.update(
                mapOf(
                    "scoreA" to scoreA,
                    "scoreB" to scoreB,
                    "status" to status.name,
                    "updatedAt" to FieldValue.serverTimestamp()
                )
            ).await()
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.UPDATE, docPath)
            Result.failure(e)
        }
    }

    suspend fun finalizeMatchAndAdvance(
        userId: String,
        tournament: Tournament,
        match: Match,
        allMatches: List<Match>,
        teams: List<Team>,
        scoreA: Long,
        scoreB: Long
    ): Result<Unit> {
        val docPath = "users/$userId/tournaments/${tournament.id}/matches/${match.id}"
        return try {
            require(scoreA in 0L..999L && scoreB in 0L..999L) { "Scores must be between 0 and 999." }
            require(match.statusEnum != MatchStatus.COMPLETED) { "Match is already finalized." }
            require(match.isPlayable) { "Both teams must be assigned before finalizing." }

            if (tournament.formatEnum == TournamentFormat.SINGLE_ELIMINATION) {
                require(scoreA != scoreB) { "Knockout matches cannot end in a tie." }
            }

            val uid = requireUserId(userId)
            val tRef = tournamentsCol(uid).document(tournament.id)
            val matchRef = tRef.collection("matches").document(match.id)

            val winnerTeamId: String?
            val winnerTeamName: String
            val winnerTeamTag: String

            when {
                scoreA > scoreB -> {
                    winnerTeamId = match.teamAId
                    winnerTeamName = match.teamAName
                    winnerTeamTag = match.teamATag
                }
                scoreB > scoreA -> {
                    winnerTeamId = match.teamBId
                    winnerTeamName = match.teamBName
                    winnerTeamTag = match.teamBTag
                }
                else -> {
                    winnerTeamId = null
                    winnerTeamName = "Draw"
                    winnerTeamTag = "DRAW"
                }
            }

            val batch = db.batch()
            val matchUpdate = mapOf(
                "scoreA" to scoreA,
                "scoreB" to scoreB,
                "status" to MatchStatus.COMPLETED.name,
                "winnerTeamId" to winnerTeamId,
                "winnerTeamName" to winnerTeamName,
                "updatedAt" to FieldValue.serverTimestamp()
            ).filterValues { it != null }
            batch.update(matchRef, matchUpdate)

            // Advance bracket winner if applicable
            if (match.nextMatchId != null && winnerTeamId != null) {
                val nextRef = tRef.collection("matches").document(match.nextMatchId)
                val slotFields = if (match.nextMatchSlot == "A") {
                    mapOf(
                        "teamAId" to winnerTeamId,
                        "teamAName" to winnerTeamName,
                        "teamATag" to winnerTeamTag,
                        "updatedAt" to FieldValue.serverTimestamp()
                    )
                } else {
                    mapOf(
                        "teamBId" to winnerTeamId,
                        "teamBName" to winnerTeamName,
                        "teamBTag" to winnerTeamTag,
                        "updatedAt" to FieldValue.serverTimestamp()
                    )
                }
                batch.update(nextRef, slotFields)
            }

            // Compute tournament completion state
            val updatedMatches = allMatches.map {
                if (it.id == match.id) {
                    it.copy(
                        scoreA = scoreA,
                        scoreB = scoreB,
                        status = MatchStatus.COMPLETED.name,
                        winnerTeamId = winnerTeamId,
                        winnerTeamName = winnerTeamName
                    )
                } else it
            }
            val newCompletedCount = updatedMatches.count { it.statusEnum == MatchStatus.COMPLETED }.toLong()
                .coerceAtMost(tournament.totalMatchCount.coerceAtLeast(1L))
            val allDone = updatedMatches.isNotEmpty() && updatedMatches.all { it.statusEnum == MatchStatus.COMPLETED }

            val tournamentUpdate = if (allDone) {
                val champion = if (tournament.formatEnum == TournamentFormat.SINGLE_ELIMINATION) {
                    winnerTeamName
                } else {
                    ScheduleGenerator.computeStandings(teams, updatedMatches)
                        .firstOrNull()?.team?.name ?: winnerTeamName
                }
                mapOf(
                    "completedMatchCount" to newCompletedCount,
                    "status" to TournamentStatus.COMPLETED.name,
                    "championName" to champion,
                    "updatedAt" to FieldValue.serverTimestamp()
                )
            } else {
                mapOf(
                    "completedMatchCount" to newCompletedCount,
                    "updatedAt" to FieldValue.serverTimestamp()
                )
            }
            batch.update(tRef, tournamentUpdate)
            batch.commit().await()
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.UPDATE, docPath)
            Result.failure(e)
        }
    }

    private fun logStreamErrorIfAuthenticated(
        error: Throwable,
        operationType: OperationType,
        path: String,
        expectedUid: String
    ) {
        val firestoreError = generateSequence(error) { it.cause }
            .filterIsInstance<FirebaseFirestoreException>()
            .firstOrNull()
        if (firestoreError == null && error is CancellationException) throw error
        val exceptionToLog = firestoreError ?: (error as? Exception)
        if (exceptionToLog != null && auth.currentUser?.uid == expectedUid) {
            handleFirestoreError(exceptionToLog, operationType, path)
        }
    }
}
