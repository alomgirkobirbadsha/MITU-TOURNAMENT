package com.mitutournament.app.domain

import com.mitutournament.app.model.Match
import com.mitutournament.app.model.MatchStatus
import com.mitutournament.app.model.StandingRow
import com.mitutournament.app.model.Team
import kotlin.math.log2

data class GeneratedSchedule(
    val matches: List<Match>,
    val preCompletedCount: Long
)

object ScheduleGenerator {

    fun generateSingleElimination(
        userId: String,
        tournamentId: String,
        teams: List<Team>
    ): GeneratedSchedule {
        val sortedTeams = teams.sortedBy { it.seed }
        val count = sortedTeams.size
        require(count >= 2) { "At least 2 teams are required to start a tournament." }

        var bracketSize = 2
        while (bracketSize < count) {
            bracketSize *= 2
        }
        val totalRounds = log2(bracketSize.toDouble()).toInt()

        // Generate standard seeded slot order so top seeds meet in the final
        val seedPositions = seededOrder(bracketSize)
        val roundSlots = MutableList(totalRounds) { mutableListOf<Match>() }

        // First assign deterministic IDs for every match in every round
        for (roundIdx in 0 until totalRounds) {
            val roundNum = roundIdx + 1
            val matchCount = bracketSize shr (roundIdx + 1)
            val roundName = roundTitle(roundNum, totalRounds)
            for (m in 0 until matchCount) {
                val matchId = "r${roundNum}_m${m}"
                val nextMatchId = if (roundIdx < totalRounds - 1) "r${roundNum + 1}_m${m / 2}" else null
                val nextSlot = if (roundIdx < totalRounds - 1) if (m % 2 == 0) "A" else "B" else null
                roundSlots[roundIdx].add(
                    Match(
                        id = matchId,
                        userId = userId,
                        tournamentId = tournamentId,
                        roundNumber = roundNum.toLong(),
                        roundName = roundName,
                        matchOrder = m.toLong(),
                        status = MatchStatus.UPCOMING.name,
                        nextMatchId = nextMatchId,
                        nextMatchSlot = nextSlot,
                        byeMatch = false
                    )
                )
            }
        }

        // Populate Round 1 with seeded teams & BYEs
        var preCompleted = 0L
        val round1 = roundSlots[0]
        for (m in round1.indices) {
            val seedA = seedPositions[m * 2]
            val seedB = seedPositions[m * 2 + 1]
            val teamA = sortedTeams.getOrNull(seedA - 1)
            val teamB = sortedTeams.getOrNull(seedB - 1)

            val isBye = (teamA != null && teamB == null) || (teamA == null && teamB != null)
            val advancingTeam = teamA ?: teamB

            val baseMatch = round1[m].copy(
                teamAId = teamA?.id,
                teamAName = teamA?.name ?: "BYE",
                teamATag = teamA?.tag ?: "BYE",
                teamBId = teamB?.id,
                teamBName = teamB?.name ?: "BYE",
                teamBTag = teamB?.tag ?: "BYE",
                byeMatch = isBye
            )

            if (isBye && advancingTeam != null) {
                preCompleted += 1L
                round1[m] = baseMatch.copy(
                    status = MatchStatus.COMPLETED.name,
                    winnerTeamId = advancingTeam.id,
                    winnerTeamName = advancingTeam.name,
                    scoreA = if (teamA != null) 1L else 0L,
                    scoreB = if (teamB != null) 1L else 0L
                )
                // Advance into Round 2 immediately
                val nextId = baseMatch.nextMatchId
                val nextSlot = baseMatch.nextMatchSlot
                if (nextId != null && roundSlots.size > 1) {
                    val nextIdx = roundSlots[1].indexOfFirst { it.id == nextId }
                    if (nextIdx >= 0) {
                        val nextMatch = roundSlots[1][nextIdx]
                        roundSlots[1][nextIdx] = if (nextSlot == "A") {
                            nextMatch.copy(
                                teamAId = advancingTeam.id,
                                teamAName = advancingTeam.name,
                                teamATag = advancingTeam.tag
                            )
                        } else {
                            nextMatch.copy(
                                teamBId = advancingTeam.id,
                                teamBName = advancingTeam.name,
                                teamBTag = advancingTeam.tag
                            )
                        }
                    }
                }
            } else {
                round1[m] = baseMatch
            }
        }

        return GeneratedSchedule(
            matches = roundSlots.flatten(),
            preCompletedCount = preCompleted
        )
    }

    fun generateRoundRobin(
        userId: String,
        tournamentId: String,
        teams: List<Team>
    ): GeneratedSchedule {
        val sortedTeams = teams.sortedBy { it.seed }
        require(sortedTeams.size >= 2) { "At least 2 teams are required to start a tournament." }

        val padded: MutableList<Team?> = sortedTeams.toMutableList()
        if (padded.size % 2 != 0) {
            padded.add(null) // virtual bye slot
        }

        val n = padded.size
        val rounds = n - 1
        val matchesPerRound = n / 2
        val rotation = padded.toMutableList()
        val result = mutableListOf<Match>()

        for (r in 0 until rounds) {
            val roundNum = r + 1
            var orderInRound = 0
            for (m in 0 until matchesPerRound) {
                val home = rotation[m]
                val away = rotation[n - 1 - m]
                if (home != null && away != null) {
                    val teamA = if (r % 2 == 0) home else away
                    val teamB = if (r % 2 == 0) away else home
                    result.add(
                        Match(
                            id = "rr_r${roundNum}_m${orderInRound}",
                            userId = userId,
                            tournamentId = tournamentId,
                            roundNumber = roundNum.toLong(),
                            roundName = "Round $roundNum",
                            matchOrder = orderInRound.toLong(),
                            teamAId = teamA.id,
                            teamAName = teamA.name,
                            teamATag = teamA.tag,
                            teamBId = teamB.id,
                            teamBName = teamB.name,
                            teamBTag = teamB.tag,
                            status = MatchStatus.UPCOMING.name,
                            byeMatch = false
                        )
                    )
                    orderInRound++
                }
            }
            // Rotate all except index 0 clockwise
            val last = rotation.removeAt(rotation.lastIndex)
            rotation.add(1, last)
        }

        return GeneratedSchedule(matches = result, preCompletedCount = 0L)
    }

    fun computeStandings(teams: List<Team>, matches: List<Match>): List<StandingRow> {
        val stats = teams.associate { team ->
            team.id to MutableStanding(team)
        }.toMutableMap()

        matches.filter { !it.byeMatch && it.statusEnum == MatchStatus.COMPLETED }.forEach { match ->
            val aId = match.teamAId
            val bId = match.teamBId
            val aStats = if (aId != null) stats[aId] else null
            val bStats = if (bId != null) stats[bId] else null

            val sA = match.scoreA.toInt()
            val sB = match.scoreB.toInt()

            if (aStats != null && bStats != null) {
                aStats.played++
                bStats.played++
                aStats.scoredFor += sA
                aStats.scoredAgainst += sB
                bStats.scoredFor += sB
                bStats.scoredAgainst += sA

                when {
                    sA > sB -> {
                        aStats.won++
                        aStats.points += 3
                        bStats.lost++
                    }
                    sB > sA -> {
                        bStats.won++
                        bStats.points += 3
                        aStats.lost++
                    }
                    else -> {
                        aStats.drawn++
                        bStats.drawn++
                        aStats.points += 1
                        bStats.points += 1
                    }
                }
            }
        }

        return stats.values
            .sortedWith(
                compareByDescending<MutableStanding> { it.points }
                    .thenByDescending { it.won }
                    .thenByDescending { it.scoredFor - it.scoredAgainst }
                    .thenByDescending { it.scoredFor }
                    .thenBy { it.team.seed }
            )
            .mapIndexed { index, s ->
                StandingRow(
                    rank = index + 1,
                    team = s.team,
                    played = s.played,
                    won = s.won,
                    drawn = s.drawn,
                    lost = s.lost,
                    scoredFor = s.scoredFor,
                    scoredAgainst = s.scoredAgainst,
                    points = s.points
                )
            }
    }

    private fun seededOrder(bracketSize: Int): List<Int> {
        var seeds = listOf(1, 2)
        var currentSize = 2
        while (currentSize < bracketSize) {
            currentSize *= 2
            val next = mutableListOf<Int>()
            for (s in seeds) {
                next.add(s)
                next.add(currentSize + 1 - s)
            }
            seeds = next
        }
        return seeds
    }

    private fun roundTitle(roundNumber: Int, totalRounds: Int): String {
        val remaining = totalRounds - roundNumber
        return when (remaining) {
            0 -> "Final"
            1 -> "Semifinals"
            2 -> "Quarterfinals"
            else -> "Round $roundNumber"
        }
    }

    private class MutableStanding(
        val team: Team,
        var played: Int = 0,
        var won: Int = 0,
        var drawn: Int = 0,
        var lost: Int = 0,
        var scoredFor: Int = 0,
        var scoredAgainst: Int = 0,
        var points: Int = 0
    )
}
