package com.mitutournament.app.ui.theme

import androidx.compose.ui.graphics.Color

// Championship Arena Palette (Dark-first with high-contrast Light option)
val ArenaObsidian = Color(0xFF0A0E17)
val ArenaSlateDeep = Color(0xFF111827)
val ArenaCardSurface = Color(0xFF182235)
val ArenaCardElevated = Color(0xFF212D45)
val ArenaBorder = Color(0xFF2D3C59)

val ChampionGold = Color(0xFFFFB800)
val ChampionGoldDim = Color(0xFFD97706)
val ChampionGoldContainer = Color(0xFF3A2B05)
val OnChampionGold = Color(0xFF1A1200)

val ElectricCobalt = Color(0xFF3B82F6)
val ElectricCobaltContainer = Color(0xFF132A4F)

val VictoryEmerald = Color(0xFF10B981)
val VictoryEmeraldContainer = Color(0xFF0B3829)

val LiveCrimson = Color(0xFFEF4444)
val LiveCrimsonContainer = Color(0xFF451216)

val InkPrimaryDark = Color(0xFFF8FAFC)
val InkSecondaryDark = Color(0xFF94A3B8)

// Light Theme Tokens
val ArenaLightBg = Color(0xFFF5F7FB)
val ArenaLightSurface = Color(0xFFFFFFFF)
val ArenaLightSurfaceVariant = Color(0xFFE8EEF7)
val ArenaLightOutline = Color(0xFFCBD5E1)
val InkPrimaryLight = Color(0xFF0F172A)
val InkSecondaryLight = Color(0xFF475569)
val ChampionGoldLight = Color(0xFFB45309)
val ChampionGoldLightContainer = Color(0xFFFEF3C7)
val ElectricCobaltLight = Color(0xFF1D4ED8)
val ElectricCobaltLightContainer = Color(0xFFDBEAFE)
val VictoryEmeraldLight = Color(0xFF047857)
val VictoryEmeraldLightContainer = Color(0xFFD1FAE5)
