package com.mitutournament.app.ui.theme

import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Shapes
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.unit.dp

private val DarkArenaColorScheme = darkColorScheme(
    primary = ChampionGold,
    onPrimary = OnChampionGold,
    primaryContainer = ChampionGoldContainer,
    onPrimaryContainer = ChampionGold,
    secondary = ElectricCobalt,
    onSecondary = InkPrimaryDark,
    secondaryContainer = ElectricCobaltContainer,
    onSecondaryContainer = InkPrimaryDark,
    tertiary = VictoryEmerald,
    onTertiary = ArenaObsidian,
    tertiaryContainer = VictoryEmeraldContainer,
    onTertiaryContainer = VictoryEmerald,
    error = LiveCrimson,
    onError = InkPrimaryDark,
    errorContainer = LiveCrimsonContainer,
    onErrorContainer = LiveCrimson,
    background = ArenaObsidian,
    onBackground = InkPrimaryDark,
    surface = ArenaSlateDeep,
    onSurface = InkPrimaryDark,
    surfaceVariant = ArenaCardSurface,
    onSurfaceVariant = InkSecondaryDark,
    surfaceContainer = ArenaCardSurface,
    surfaceContainerHigh = ArenaCardElevated,
    outline = ArenaBorder,
    outlineVariant = ArenaBorder
)

private val LightArenaColorScheme = lightColorScheme(
    primary = ChampionGoldLight,
    onPrimary = ArenaLightSurface,
    primaryContainer = ChampionGoldLightContainer,
    onPrimaryContainer = ChampionGoldLight,
    secondary = ElectricCobaltLight,
    onSecondary = ArenaLightSurface,
    secondaryContainer = ElectricCobaltLightContainer,
    onSecondaryContainer = ElectricCobaltLight,
    tertiary = VictoryEmeraldLight,
    onTertiary = ArenaLightSurface,
    tertiaryContainer = VictoryEmeraldLightContainer,
    onTertiaryContainer = VictoryEmeraldLight,
    error = LiveCrimson,
    onError = ArenaLightSurface,
    errorContainer = LiveCrimsonContainer,
    onErrorContainer = LiveCrimson,
    background = ArenaLightBg,
    onBackground = InkPrimaryLight,
    surface = ArenaLightSurface,
    onSurface = InkPrimaryLight,
    surfaceVariant = ArenaLightSurfaceVariant,
    onSurfaceVariant = InkSecondaryLight,
    surfaceContainer = ArenaLightSurface,
    surfaceContainerHigh = ArenaLightSurfaceVariant,
    outline = ArenaLightOutline,
    outlineVariant = ArenaLightOutline
)

val ArenaShapes = Shapes(
    small = RoundedCornerShape(10.dp),
    medium = RoundedCornerShape(16.dp),
    large = RoundedCornerShape(22.dp),
    extraLarge = RoundedCornerShape(28.dp)
)

@Composable
fun MituTournamentTheme(
    darkTheme: Boolean = true,
    content: @Composable () -> Unit
) {
    val colorScheme = if (darkTheme) DarkArenaColorScheme else LightArenaColorScheme
    MaterialTheme(
        colorScheme = colorScheme,
        typography = Typography,
        shapes = ArenaShapes,
        content = content
    )
}
