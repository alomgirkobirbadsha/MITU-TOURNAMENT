package com.mitutournament.app.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import com.google.firebase.auth.FirebaseUser
import com.google.firebase.firestore.ListenerRegistration
import com.mitutournament.app.chess.ChessPosition
import com.mitutournament.app.data.ChallengeItem
import com.mitutournament.app.data.LiveGame
import com.mitutournament.app.data.MituRepository
import kotlinx.coroutines.launch

@Composable
fun HomeScreen(user: FirebaseUser, onSignOut: () -> Unit, onOpenGame: (String) -> Unit) {
    var tab by remember { mutableStateOf(0) }
    Column(Modifier.fillMaxSize().background(MaterialTheme.colorScheme.background)) {
        Row(Modifier.fillMaxWidth().padding(horizontal = 18.dp, vertical = 14.dp), verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text("MITU TOURNAMENT", fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleLarge)
                Text("স্বাগতম, ${user.displayName ?: user.email.orEmpty()}", color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
            TextButton(onClick = onSignOut) { Text("লগআউট") }
        }
        Row(Modifier.fillMaxWidth().padding(horizontal = 16.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Button(onClick = { tab = 0 }, modifier = Modifier.weight(1f)) { Text("চ্যালেঞ্জ") }
            Button(onClick = { tab = 1 }, modifier = Modifier.weight(1f)) { Text("প্রোফাইল") }
        }
        if (tab == 0) ChallengesScreen(user = user, onOpenGame = onOpenGame)
        else ProfileScreen(user = user)
    }
}

@Composable
private fun ChallengesScreen(user: FirebaseUser, onOpenGame: (String) -> Unit) {
    val repo = remember { MituRepository() }
    val scope = rememberCoroutineScope()
    var targetEmail by remember { mutableStateOf("") }
    var challenges by remember { mutableStateOf(emptyList<ChallengeItem>()) }
    var message by remember { mutableStateOf("") }
    var busy by remember { mutableStateOf(false) }
    DisposableEffect(user.uid) {
        val listener: ListenerRegistration = repo.listenChallenges(user.uid) { items, error ->
            challenges = items
            if (error != null) message = error
        }
        onDispose { listener.remove() }
    }
    Column(Modifier.fillMaxSize().padding(horizontal = 16.dp, vertical = 10.dp)) {
        Text("বন্ধুকে চ্যালেঞ্জ পাঠান", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
        OutlinedTextField(targetEmail, { targetEmail = it }, label = { Text("প্রতিপক্ষের রেজিস্টার্ড ইমেইল") }, modifier = Modifier.fillMaxWidth(), singleLine = true)
        Button(onClick = {
            scope.launch {
                busy = true; message = ""
                try { repo.sendChallenge(user.uid, user.displayName ?: user.email.orEmpty(), user.email.orEmpty(), targetEmail); targetEmail = ""; message = "চ্যালেঞ্জ পাঠানো হয়েছে" }
                catch (e: Exception) { message = e.localizedMessage ?: "চ্যালেঞ্জ পাঠানো যায়নি" }
                finally { busy = false }
            }
        }, enabled = !busy && targetEmail.isNotBlank(), modifier = Modifier.fillMaxWidth()) { Text(if (busy) "পাঠানো হচ্ছে…" else "চ্যালেঞ্জ পাঠান") }
        if (message.isNotBlank()) Text(message, color = MaterialTheme.colorScheme.primary, modifier = Modifier.padding(vertical = 6.dp))
        Spacer(Modifier.height(8.dp))
        Text("আপনার চ্যালেঞ্জ ও ম্যাচ", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
        LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.weight(1f)) {
            items(challenges, key = { it.id }) { item ->
                ChallengeCard(item, user.uid, onOpenGame) { accept ->
                    scope.launch {
                        try {
                            val gameId = repo.respondToChallenge(item.id, accept)
                            if (gameId != null) onOpenGame(gameId)
                            else message = if (accept) "ম্যাচ শুরু হয়েছে" else "চ্যালেঞ্জ প্রত্যাখ্যান করা হয়েছে"
                        } catch (e: Exception) { message = e.localizedMessage ?: "কাজটি সম্পন্ন হয়নি" }
                    }
                }
            }
        }
    }
}

@Composable
private fun ChallengeCard(item: ChallengeItem, uid: String, onOpenGame: (String) -> Unit, onRespond: (Boolean) -> Unit) {
    val incoming = item.toUid == uid
    Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant), modifier = Modifier.fillMaxWidth()) {
        Column(Modifier.padding(14.dp)) {
            Text(if (incoming) "${item.fromName} আপনাকে চ্যালেঞ্জ করেছে" else "আপনি ${item.toName}-কে চ্যালেঞ্জ করেছেন", fontWeight = FontWeight.SemiBold)
            Text("অবস্থা: ${when(item.status){"pending"->"অপেক্ষমাণ";"accepted"->"গেম শুরু";"rejected"->"প্রত্যাখ্যাত";else->item.status}}", color = MaterialTheme.colorScheme.onSurfaceVariant)
            if (item.status == "pending" && incoming) Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Button(onClick = { onRespond(true) }, modifier = Modifier.weight(1f)) { Text("গ্রহণ করুন") }
                TextButton(onClick = { onRespond(false) }, modifier = Modifier.weight(1f)) { Text("প্রত্যাখ্যান") }
            }
            if (item.status == "accepted" && item.gameId != null) Button(onClick = { onOpenGame(item.gameId) }, modifier = Modifier.fillMaxWidth()) { Text("ম্যাচে প্রবেশ করুন") }
        }
    }
}

@Composable
private fun ProfileScreen(user: FirebaseUser) {
    Column(Modifier.fillMaxSize().padding(22.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        Text("আমার প্রোফাইল", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
        Text("নাম: ${user.displayName ?: "খেলোয়াড়"}")
        Text("ইমেইল: ${user.email.orEmpty()}")
        Text("Player ID: ${user.uid}", color = MaterialTheme.colorScheme.onSurfaceVariant)
    }
}

@Composable
fun GameScreen(gameId: String, uid: String, onBack: () -> Unit) {
    val repo = remember { MituRepository() }
    val scope = rememberCoroutineScope()
    var game by remember(gameId) { mutableStateOf<LiveGame?>(null) }
    var error by remember { mutableStateOf("") }
    var selected by remember(gameId) { mutableStateOf<Int?>(null) }
    var busy by remember { mutableStateOf(false) }
    DisposableEffect(gameId) {
        val listener = repo.listenGame(gameId) { value, err -> game = value; if (err != null) error = err }
        onDispose { listener.remove() }
    }
    val current = game
    Column(Modifier.fillMaxSize().padding(12.dp), horizontalAlignment = Alignment.CenterHorizontally) {
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
            TextButton(onClick = onBack) { Text("← ফিরে যান") }
            Text("অনলাইন দাবা", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
        }
        if (current == null) Text("ম্যাচ লোড হচ্ছে…") else {
            val whiteSide = uid == current.whiteUid
            Text("সাদা: ${current.whiteName}    কালো: ${current.blackName}", textAlign = TextAlign.Center)
            Text(
                when(current.status) { "completed" -> if(current.winnerUid.isNullOrBlank()) "ড্র" else "ম্যাচ শেষ — বিজয়ী ${if(current.winnerUid==current.whiteUid) current.whiteName else current.blackName}"; else -> if(current.turnUid==uid) "আপনার চাল" else "প্রতিপক্ষের চাল" },
                color = MaterialTheme.colorScheme.primary, fontWeight = FontWeight.Bold, modifier = Modifier.padding(8.dp)
            )
            val position = remember(current.fen) { ChessPosition.fromFen(current.fen) }
            Column(Modifier.fillMaxWidth().aspectRatio(1f)) {
                for (visualRow in 0..7) Row(Modifier.weight(1f)) {
                    for (visualCol in 0..7) {
                        val index = if (whiteSide) visualRow * 8 + visualCol else (7 - visualRow) * 8 + (7 - visualCol)
                        val piece = position.pieceAt(index)
                        val light = ((index / 8) + (index % 8)) % 2 == 0
                        val chosen = selected == index
                        Box(
                            Modifier.weight(1f).fillMaxSize()
                                .background(if(chosen) Color(0xFFE5B94B) else if(light) Color(0xFFF0D9B5) else Color(0xFF8B5A3C))
                                .clickable(enabled = current.status == "active" && current.turnUid == uid && !busy) {
                                    val old = selected
                                    if (old == null) {
                                        if (piece != ' ' && piece.isUpperCase() == whiteSide) selected = index
                                    } else if (old == index) selected = null
                                    else {
                                        scope.launch {
                                            busy = true; error = ""
                                            try { repo.makeMove(current, uid, old, index); selected = null }
                                            catch (e: Exception) { error = e.localizedMessage ?: "চাল দেওয়া যায়নি"; selected = if(piece!=' ' && piece.isUpperCase()==whiteSide) index else null }
                                            finally { busy = false }
                                        }
                                    }
                                }, contentAlignment = Alignment.Center
                        ) {
                            Text(pieceGlyph(piece), style = MaterialTheme.typography.headlineMedium, color = if(piece.isUpperCase()) Color(0xFFFFFFFF) else Color(0xFF151515))
                        }
                    }
                }
            }
            if (busy) Text("চাল পাঠানো হচ্ছে…")
            Text("একটি ঘুঁটি বেছে নিয়ে গন্তব্য ঘরে চাপ দিন", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
        if (error.isNotBlank()) Text(error, color = MaterialTheme.colorScheme.error, modifier = Modifier.padding(8.dp))
    }
}

private fun pieceGlyph(piece: Char): String = when(piece) {
    'K' -> "♔"; 'Q' -> "♕"; 'R' -> "♖"; 'B' -> "♗"; 'N' -> "♘"; 'P' -> "♙"
    'k' -> "♚"; 'q' -> "♛"; 'r' -> "♜"; 'b' -> "♝"; 'n' -> "♞"; 'p' -> "♟"
    else -> ""
}
