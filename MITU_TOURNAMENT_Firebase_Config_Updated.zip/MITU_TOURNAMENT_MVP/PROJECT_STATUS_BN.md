# প্রকল্পের বর্তমান অবস্থা

প্রজেক্টের নাম: MITU TOURNAMENT
Android package: `com.mitutournament.app`
Firebase project: `mitu-tournament`

## এই ZIP-এ কোড করা হয়েছে
- Firebase Email/Password রেজিস্ট্রেশন ও লগইন (কোডে যুক্ত)
- রেজিস্ট্রেশনে নাম/ইমেইল/পাসওয়ার্ড যাচাই, পাসওয়ার্ড নিশ্চিতকরণ
- পাসওয়ার্ড ভুলে গেলে Firebase reset email পাঠানোর ব্যবস্থা
- লগইনে পুরোনো অসম্পূর্ণ অ্যাকাউন্টের users প্রোফাইল পুনরুদ্ধারের ব্যবস্থা
- users প্রোফাইল ডকুমেন্ট
- ইমেইল দিয়ে প্লেয়ার চ্যালেঞ্জ পাঠানো
- চ্যালেঞ্জ গ্রহণ/প্রত্যাখ্যান
- Firestore listener দিয়ে লাইভ গেম আপডেট
- FEN-ভিত্তিক দাবার বোর্ড ও সাধারণ বৈধ চাল যাচাই
- চেক, চেকমেট, স্টেলমেট, কাস্টলিং, এন-পাসাঁ ও কুইন প্রমোশন

## এই আপডেটে পরিবর্তন
- AuthScreen.kt এবং MituRepository.kt আপডেট করা হয়েছে।
- নতুন প্লেয়ারের জন্য role=player, rating=1200, wins/losses/draws=0 সহ users প্রোফাইল তৈরি হয়।
- এই পরিবেশে Android SDK/Gradle wrapper script নেই; তাই এখানে APK build বা emulator/device test চালানো সম্ভব হয়নি।

## এখনো বাস্তব ডিভাইসে পরীক্ষা করা হয়নি
- Firebase Authentication-এ Email/Password চালু করা
- Firestore rules Firebase Console-এ publish করা
- দুইটি আলাদা অ্যাকাউন্টে চ্যালেঞ্জ/গেম পরীক্ষা
- Android Studio Gradle Sync ও APK Build

## পরবর্তী উন্নয়ন
- সার্ভার-সাইড চাল যাচাই ও নিরাপত্তা
- গেম ঘড়ি, রিজাইন, ড্র অফার, ৫০-মুভ/থ্রি-ফোল্ড ড্র
- ম্যাচ হিস্ট্রি স্ক্রিন, রেটিং/লিডারবোর্ড, টুর্নামেন্ট

এই সংস্করণে টাকা Wallet, Entry Fee বা পেমেন্ট নেই।
