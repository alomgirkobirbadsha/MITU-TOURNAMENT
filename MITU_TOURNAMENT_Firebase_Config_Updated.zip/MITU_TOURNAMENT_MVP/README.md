# MITU TOURNAMENT — Android MVP

This project is the first MVP foundation for MITU TOURNAMENT. The current app flow is intentionally limited to:

- Email/password registration and login with Firebase Authentication
- Player profile basics stored in Cloud Firestore
- Player-to-player challenges by registered email (send, accept, reject)
- Realtime two-player chess board backed by Firestore game documents
- Basic standard chess move validation, check/checkmate/stalemate, castling, en-passant and automatic queen promotion

There is no cash wallet, no entry fee, and no paid tournament flow in this MVP. Coins/diamonds and tournament features are deferred.

## Firebase setup

1. The Android app package is `com.mitutournament.app`.
2. `app/google-services.json` is configured for Firebase project `mitu-tournament` and the Android app `com.mitutournament.app`.
3. In Firebase Console, open **Authentication → Sign-in method** and enable **Email/Password**.
4. Create/confirm the Cloud Firestore **(default)** database in the same Firebase project.
5. Publish the root `firestore.rules` rules to Cloud Firestore.
6. Do not use the AI Studio project `gen-lang-client-0650930015` or package `com.aistudio.mituturnament.vqrzkm` for this app.

## Firestore collections used by the MVP

- `users/{uid}` — display name, email, uid, createdAt
- `challenges/{challengeId}` — sender, recipient, participants, status, gameId
- `games/{gameId}` — players, FEN position, whose turn, move history and result

## Build

Open this folder as a Gradle project in Android Studio, allow Gradle sync, then run the `app` configuration on an Android device (min SDK 24). The source archive did not include a Gradle wrapper JAR or a locally verified Android SDK, so a successful APK build has not been claimed here.

## Important testing and production notes

- Test registration, login, challenge delivery, acceptance/rejection, two-device live moves, reconnects and game completion using two separate Firebase test accounts.
- Firestore security rules are included as a starting policy. For production-grade competitive chess, move legality and clocks should be validated by trusted server-side Cloud Functions; client-side validation alone is not tamper-proof.
- The chess MVP does not yet implement tournament brackets, ratings, clocks, draw offers, resignation, threefold repetition or the 50-move draw rule.
- Keep your own backup of this ZIP and the Firebase project. Do not share service credentials or private signing keys.
